# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: kaplay-prediction-preview.spec.ts >> Kaplay prediction preview >> preserves a dirty saved custom prediction through same-session runtime failure
- Location: tests/e2e/kaplay-prediction-preview.spec.ts:1458:7

# Error details

```
Error: page.evaluate: Error: Kaplay choice layout is not currently hit-testable.
    at eval (eval at evaluate (:311:30), <anonymous>:8:13)
    at UtilityScript.evaluate (<anonymous>:313:16)
    at UtilityScript.<anonymous> (<anonymous>:1:44)
```

# Page snapshot

```yaml
- generic [ref=f3e3]:
  - banner [ref=f3e4]:
    - generic [ref=f3e5]:
      - link "Rugby Rooster" [ref=f3e6] [cursor=pointer]:
        - /url: /
        - generic [aria-hidden] [ref=f3e7]: RR
      - navigation "Primary navigation" [ref=f3e9]:
        - list [ref=f3e10]:
          - listitem [ref=f3e11]:
            - link "Rugby Rooster" [ref=f3e12] [cursor=pointer]:
              - /url: /
          - listitem [ref=f3e13]:
            - link "Games" [ref=f3e14] [cursor=pointer]:
              - /url: /games
          - listitem [ref=f3e15]:
            - link "Account" [ref=f3e16] [cursor=pointer]:
              - /url: /account
          - listitem [ref=f3e17]:
            - button "Sign out" [ref=f3e19] [cursor=pointer]
  - main [ref=f3e20]:
    - generic [ref=f3e21]:
      - link "Back to fixture" [ref=f3e22] [cursor=pointer]:
        - /url: /games/gEHZssYoZR8XfAiXS
      - generic [ref=f3e23]:
        - generic [ref=f3e24]: Published
        - generic [ref=f3e25]: Open before kickoff
        - generic [ref=f3e26]: Dirty Preview Cup
      - heading "Springboks Dirty mu78tanh7222 vs All Blacks Dirty mu78tanhffba" [level=1] [ref=f3e27]
      - paragraph [ref=f3e28]: "Kickoff: 01 Jun 2098, 14:00 SAST"
    - generic [ref=f3e29]:
      - generic [ref=f3e31]:
        - generic [ref=f3e32]:
          - paragraph [ref=f3e33]: Animations
          - paragraph [ref=f3e34]: Animated Match Result is available. Other prediction steps currently use the standard experience.
        - group "Animations" [ref=f3e35]:
          - button "Off" [ref=f3e36] [cursor=pointer]
          - button "On" [pressed] [ref=f3e37] [cursor=pointer]
      - generic [ref=f3e38]:
        - group "Step 1 of 10" [ref=f3e39]
        - generic [ref=f3e51]:
          - paragraph [ref=f3e52]: Step 1 of 10
          - heading "TIME TO PICK A SIDE!" [level=2] [ref=f3e53]
          - paragraph [ref=f3e54]: Who gets the result?
          - paragraph [ref=f3e55]: Get the result wrong and lose 5,000 points—half your starting score. Pick carefully!
        - generic "TIME TO PICK A SIDE!" [ref=f3e57]
        - group "TIME TO PICK A SIDE!" [ref=f3e58]:
          - generic [ref=f3e59]: Match Result animation choices
          - generic [ref=f3e60]:
            - radio "Springboks Dirty mu78tanh7222" [checked] [ref=f3e61]
            - text: Springboks Dirty mu78tanh7222
        - status [ref=f3e62]: You picked Springboks Dirty mu78tanh7222
        - button "Change my selection" [ref=f3e64] [cursor=pointer]
        - generic [ref=f3e65]:
          - button "Back" [ref=f3e66] [cursor=pointer]
          - generic [ref=f3e67]:
            - button "Return to Review" [ref=f3e68] [cursor=pointer]
            - button "Continue" [ref=f3e69] [cursor=pointer]
  - contentinfo [ref=f3e70]:
    - generic [ref=f3e71]:
      - paragraph [ref=f3e72]: Rugby Rooster account access build.
      - link "Admin" [ref=f3e73] [cursor=pointer]:
        - /url: /admin
```