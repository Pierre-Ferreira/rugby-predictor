# CCPP-009C2 EOMD Source/Run/Evidence Manifest

Package: rugby-rooster-ccpp009c2-compact-layout-playback-eomd-20260918.zip
Created: 2026-09-18

Repository contents:
- focused Match Result Kaplay source under imports/ui/predictions/kaplay/
- relevant prediction host/session context
- current focused unit/browser tests and local browser settings
- prepared Rooster source/runtime assets and preparation script
- updated audit/checkpoint/platform/product/map documentation

Evidence contents:
- browser-attempt-1: launch manifest, exit record, .last-run.json, process events
- browser-rerun: launch manifest, exit record, Playwright stdout/stderr, runner output, process events
- browser-rerun media: normal/slowed WebMs, contact sheets, extracted frames
- browser-rerun screenshots: desktop, 390 px, 360 px, Standard fallback/interruption
- browser-rerun measurements: mobile-layout-measurements.json
- failure evidence: screenshot, video, sanitized error-context.md
- per-test sanitized browser JSON evidence with query strings redacted by the collector

Excluded intentionally:
- raw Playwright trace ZIPs
- raw process snapshots containing unrelated local process details
- dependencies, Meteor/build caches, private settings, secrets, unrelated archives

Recorded browser result:
- first attempt: exit code 1 before executable cases, failedTests empty
- second attempt: 7 passed / 1 failed
- dirty-session test precondition corrected after 7/8 run; browser correction not rerun

Closeout checks:
- npm run typecheck: passed
- npm run lint: passed
- npm run lint:project: passed
- Prettier changed-file check: passed
- git diff --check: passed
- ffprobe normal WebM: 65 frames
- ffprobe slowed WebM: 117 frames
- ffprobe failure video: 14.000000 seconds, 350 frames
