# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: kaplay-prediction-preview.spec.ts >> Kaplay prediction preview >> uses Standard when reduced motion blocks automatic activation
- Location: tests/e2e/kaplay-prediction-preview.spec.ts:1455:7

# Error details

```
Error: page.evaluate: Error: Kaplay choice layout is not currently hit-testable.
    at eval (eval at evaluate (:311:30), <anonymous>:8:13)
    at UtilityScript.evaluate (<anonymous>:313:16)
    at UtilityScript.<anonymous> (<anonymous>:1:44)
```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - banner [ref=f2e4]:
    - generic [ref=f2e5]:
      - link "Rugby Rooster" [ref=f2e6] [cursor=pointer]:
        - /url: /
        - generic [aria-hidden] [ref=f2e7]: RR
      - navigation "Primary navigation" [ref=f2e9]:
        - list [ref=f2e10]:
          - listitem [ref=f2e11]:
            - link "Rugby Rooster" [ref=f2e12] [cursor=pointer]:
              - /url: /
          - listitem [ref=f2e13]:
            - link "Games" [ref=f2e14] [cursor=pointer]:
              - /url: /games
          - listitem [ref=f2e15]:
            - link "Account" [ref=f2e16] [cursor=pointer]:
              - /url: /account
          - listitem [ref=f2e17]:
            - button "Sign out" [ref=f2e19] [cursor=pointer]
  - main [ref=f2e20]:
    - generic [ref=f2e21]:
      - link "Back to fixture" [ref=f2e22] [cursor=pointer]:
        - /url: /games/Zt3tWD7r38o7b8dx6
      - generic [ref=f2e23]:
        - generic [ref=f2e24]: Published
        - generic [ref=f2e25]: Open before kickoff
        - generic [ref=f2e26]: kaplay-reduced-motion Cup
      - heading "Cape Town Very Long Club Name mu8mx7dk30d7 XV vs Johannesburg Equally Long Club Name mu8mx7dk730a XV" [level=1] [ref=f2e27]
      - paragraph [ref=f2e28]: "Kickoff: 01 Jun 2098, 14:00 SAST"
    - generic [ref=f2e29]:
      - generic [ref=f2e31]:
        - generic [ref=f2e32]:
          - paragraph [ref=f2e33]: Animations
          - paragraph [ref=f2e34]: Animated Match Result is available. Other prediction steps currently use the standard experience.
        - group "Animations" [ref=f2e35]:
          - button "Off" [ref=f2e36] [cursor=pointer]
          - button "On" [pressed] [ref=f2e37] [cursor=pointer]
      - generic [ref=f2e38]:
        - group "Step 1 of 9" [ref=f2e39]
        - generic [ref=f2e50]:
          - paragraph [ref=f2e51]: Step 1 of 9
          - heading "WHO DO YOU THINK WILL WIN?" [level=2] [ref=f2e52]
          - paragraph [ref=f2e53]: Get the result wrong and lose 5,000 points—half your starting score. Pick carefully!
        - generic "WHO DO YOU THINK WILL WIN?" [ref=f2e55]
        - group "WHO DO YOU THINK WILL WIN?" [ref=f2e56]:
          - generic [ref=f2e57]: Match Result animation choices
          - generic [ref=f2e58]:
            - radio "Cape Town Very Long Club Name mu8mx7dk30d7 XV" [checked] [active] [ref=f2e59]
            - text: Cape Town Very Long Club Name mu8mx7dk30d7 XV
          - generic [ref=f2e60]:
            - radio "Johannesburg Equally Long Club Name mu8mx7dk730a XV" [ref=f2e61]
            - text: Johannesburg Equally Long Club Name mu8mx7dk730a XV
          - generic [ref=f2e62]:
            - radio "Draw" [ref=f2e63]
            - text: Draw
        - generic [ref=f2e64]:
          - button "Back" [ref=f2e65] [cursor=pointer]
          - button "Continue" [ref=f2e67] [cursor=pointer]
  - contentinfo [ref=f2e68]:
    - generic [ref=f2e69]:
      - paragraph [ref=f2e70]: Rugby Rooster account access build.
      - link "Admin" [ref=f2e71] [cursor=pointer]:
        - /url: /admin
```