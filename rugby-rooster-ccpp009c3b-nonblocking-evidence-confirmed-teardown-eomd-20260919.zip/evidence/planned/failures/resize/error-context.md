# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: kaplay-prediction-preview.spec.ts >> Kaplay prediction preview >> keeps canvas coordinates synchronized across desktop compact desktop resizing
- Location: tests/e2e/kaplay-prediction-preview.spec.ts:1169:7

# Error details

```
TimeoutError: page.waitForFunction: Timeout 15000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - banner [ref=f2e4]:
    - generic [ref=f2e5]:
      - link "Rugby Rooster" [ref=f2e6] [cursor=pointer]:
        - /url: /
        - generic [aria-hidden] [ref=f2e7]: RR
      - navigation "Primary navigation" [ref=f2e9]:
        - list [ref=f2e10]:
          - listitem [ref=f2e11]:
            - link "Rugby Rooster" [ref=f2e12] [cursor=pointer]:
              - /url: /
          - listitem [ref=f2e13]:
            - link "Games" [ref=f2e14] [cursor=pointer]:
              - /url: /games
          - listitem [ref=f2e15]:
            - link "Account" [ref=f2e16] [cursor=pointer]:
              - /url: /account
          - listitem [ref=f2e17]:
            - button "Sign out" [ref=f2e19] [cursor=pointer]
  - main [ref=f2e20]:
    - generic [ref=f2e21]:
      - link "Back to fixture" [ref=f2e22] [cursor=pointer]:
        - /url: /games/zx322z2DReYp4JnrB
      - generic [ref=f2e23]:
        - generic [ref=f2e24]: Published
        - generic [ref=f2e25]: Open before kickoff
        - generic [ref=f2e26]: kaplay-resize-sync Cup
      - heading "Cape Town Longform Rugby Football Club mu8mwkee3b3d XV vs Johannesburg Longform Rugby Football Club mu8mwkee585c XV" [level=1] [ref=f2e27]
      - paragraph [ref=f2e28]: "Kickoff: 01 Jun 2098, 14:00 SAST"
    - generic [ref=f2e29]:
      - generic [ref=f2e30]:
        - generic [ref=f2e31]:
          - generic [ref=f2e32]:
            - paragraph [ref=f2e33]: Animations
            - paragraph [ref=f2e34]: Animated Match Result is available. Other prediction steps currently use the standard experience.
          - group "Animations" [ref=f2e35]:
            - button "Off" [ref=f2e36] [cursor=pointer]
            - button "On" [pressed] [ref=f2e37] [cursor=pointer]
        - alert [ref=f2e38]:
          - paragraph [ref=f2e39]: Animations couldn't continue. Your answers have been kept.
          - button "Retry animations" [ref=f2e40] [cursor=pointer]
      - generic [ref=f2e42]:
        - group "Step 1 of 9" [ref=f2e43]
        - generic [ref=f2e54]:
          - paragraph [ref=f2e55]: Step 1 of 9
          - heading "WHO DO YOU THINK WILL WIN?" [level=2] [ref=f2e56]
          - paragraph [ref=f2e57]: Get the result wrong and lose 5,000 points—half your starting score. Pick carefully!
          - paragraph [ref=f2e59]: "Choices: Cape Town Longform Rugby Football Club mu8mwkee3b3d XV, Johannesburg Longform Rugby Football Club mu8mwkee585c XV, or Draw."
        - group "Who do you think will win?" [ref=f2e61]:
          - generic [ref=f2e63]:
            - generic [ref=f2e64] [cursor=pointer]:
              - radio "Cape Town Longform Rugby Football Club mu8mwkee3b3d XV" [ref=f2e65]
              - generic [ref=f2e66]: Cape Town Longform Rugby Football Club mu8mwkee3b3d XV
            - generic [ref=f2e67] [cursor=pointer]:
              - radio "Johannesburg Longform Rugby Football Club mu8mwkee585c XV" [checked] [ref=f2e68]
              - generic [ref=f2e69]: Johannesburg Longform Rugby Football Club mu8mwkee585c XV
            - generic [ref=f2e70] [cursor=pointer]:
              - radio "Draw" [ref=f2e71]
              - generic [ref=f2e72]: Draw
          - paragraph [ref=f2e73]: You picked Johannesburg Longform Rugby Football Club mu8mwkee585c XV
        - generic [ref=f2e74]:
          - button "Back" [ref=f2e75] [cursor=pointer]
          - button "Continue" [ref=f2e77] [cursor=pointer]
  - contentinfo [ref=f2e78]:
    - generic [ref=f2e79]:
      - paragraph [ref=f2e80]: Rugby Rooster account access build.
      - link "Admin" [ref=f2e81] [cursor=pointer]:
        - /url: /admin
```

# Test source

```ts
  555 |   await page.waitForFunction(
  556 |     () => {
  557 |       const layout = window.__RUGBY_ROOSTER_KAPLAY_LAST_LAYOUT__;
  558 | 
  559 |       return (
  560 |         Boolean(layout) &&
  561 |         Array.isArray(layout?.choices) &&
  562 |         layout.choices.length > 0 &&
  563 |         layout.synchronized === true &&
  564 |         layout.viewport.renderedContentBounds !== null &&
  565 |         layout.viewport.engine.width === layout.stage.width &&
  566 |         layout.viewport.engine.height === layout.stage.height
  567 |       );
  568 |     },
  569 |     undefined,
  570 |     { timeout: NAVIGATION_ATTEMPT_TIMEOUT_MS },
  571 |   );
  572 | };
  573 | 
  574 | const waitForHitTestableChoices = async (page: Page) => {
  575 |   await waitForKaplayDebugLayout(page);
  576 |   await page.waitForFunction(
  577 |     () => {
  578 |       const layout = window.__RUGBY_ROOSTER_KAPLAY_LAST_LAYOUT__;
  579 | 
  580 |       return (
  581 |         layout?.synchronized === true &&
  582 |         layout.selectedChoice === null &&
  583 |         layout.choices.length === 3 &&
  584 |         layout.choices.every((choice) => choice.hitTestable)
  585 |       );
  586 |     },
  587 |     undefined,
  588 |     { timeout: NAVIGATION_ATTEMPT_TIMEOUT_MS },
  589 |   );
  590 | };
  591 | 
  592 | const retryIfAnimationFailureIsVisible = async (page: Page) => {
  593 |   const retryButton = page.getByRole('button', { name: 'Retry animations' });
  594 | 
  595 |   if (
  596 |     await retryButton
  597 |       .isVisible({
  598 |         timeout: 1_000,
  599 |       })
  600 |       .catch(() => false)
  601 |   ) {
  602 |     await retryButton.click();
  603 |   }
  604 | };
  605 | 
  606 | const clickCanvasChoice = async (page: Page, choiceIndex: 0 | 1 | 2) => {
  607 |   const canvas = page.getByTestId('kaplay-match-result-canvas');
  608 |   const box = await canvas.boundingBox();
  609 | 
  610 |   if (!box) {
  611 |     throw new Error('Kaplay canvas is not visible.');
  612 |   }
  613 | 
  614 |   await waitForKaplayDebugLayout(page);
  615 |   const choice = await page.evaluate((index) => {
  616 |     const layout = window.__RUGBY_ROOSTER_KAPLAY_LAST_LAYOUT__;
  617 |     const projectedChoice = layout?.choices[index];
  618 | 
  619 |     if (!layout || !projectedChoice) {
  620 |       throw new Error('Kaplay choice layout is not available.');
  621 |     }
  622 | 
  623 |     if (!projectedChoice.hitTestable) {
  624 |       throw new Error('Kaplay choice layout is not currently hit-testable.');
  625 |     }
  626 | 
  627 |     return {
  628 |       centerX: projectedChoice.rect.x + projectedChoice.rect.width / 2,
  629 |       centerY: projectedChoice.rect.y + projectedChoice.rect.height / 2,
  630 |       content: layout.viewport.renderedContentBounds,
  631 |       stageHeight: layout.stage.height,
  632 |       stageWidth: layout.stage.width,
  633 |     };
  634 |   }, choiceIndex);
  635 | 
  636 |   if (!choice.content) {
  637 |     throw new Error('Kaplay rendered content bounds are not available.');
  638 |   }
  639 | 
  640 |   await canvas.click({
  641 |     position: {
  642 |       x:
  643 |         choice.content.x +
  644 |         (choice.centerX / choice.stageWidth) * choice.content.width,
  645 |       y:
  646 |         choice.content.y +
  647 |         (choice.centerY / choice.stageHeight) * choice.content.height,
  648 |     },
  649 |   });
  650 | };
  651 | 
  652 | const collectKaplayLayoutEvidence = async (page: Page, label: string) => {
  653 |   markStage(page, 'kaplay-layout-evidence:scene-readiness-start', { label });
  654 |   await waitForKaplayDebugLayout(page);
> 655 |   await page.waitForFunction(
      |              ^ TimeoutError: page.waitForFunction: Timeout 15000ms exceeded.
  656 |     () => {
  657 |       const canvas = document.querySelector<HTMLCanvasElement>(
  658 |         '[data-testid="kaplay-match-result-canvas"]',
  659 |       );
  660 |       const layout = window.__RUGBY_ROOSTER_KAPLAY_LAST_LAYOUT__;
  661 | 
  662 |       if (!canvas || !layout) {
  663 |         return false;
  664 |       }
  665 | 
  666 |       return (
  667 |         layout.synchronized === true &&
  668 |         layout.viewport.renderedContentBounds !== null &&
  669 |         layout.viewport.engine.width === layout.stage.width &&
  670 |         layout.viewport.engine.height === layout.stage.height &&
  671 |         Math.abs(
  672 |           layout.displayScale -
  673 |             layout.viewport.renderedContentBounds.width / layout.stage.width,
  674 |         ) < 0.01
  675 |       );
  676 |     },
  677 |     undefined,
  678 |     { timeout: NAVIGATION_ATTEMPT_TIMEOUT_MS },
  679 |   );
  680 |   markStage(page, 'kaplay-layout-evidence:scene-readiness-success', { label });
  681 |   const canvas = page.getByTestId('kaplay-match-result-canvas');
  682 |   const box = await canvas.boundingBox();
  683 | 
  684 |   if (!box) {
  685 |     throw new Error('Kaplay canvas is not visible for layout evidence.');
  686 |   }
  687 | 
  688 |   const layout = await page.evaluate(() => {
  689 |     const currentLayout = window.__RUGBY_ROOSTER_KAPLAY_LAST_LAYOUT__;
  690 | 
  691 |     if (!currentLayout) {
  692 |       throw new Error('Kaplay layout evidence is not available.');
  693 |     }
  694 | 
  695 |     return currentLayout;
  696 |   });
  697 |   markStage(page, 'kaplay-layout-evidence:optional-selection-read-start', {
  698 |     label,
  699 |   });
  700 |   const selectedValue = await readKaplayMatchResultSelectedValue(page, {
  701 |     timeoutMs: NAVIGATION_ATTEMPT_TIMEOUT_MS,
  702 |   });
  703 |   markStage(page, 'kaplay-layout-evidence:optional-selection-read-success', {
  704 |     label,
  705 |     selectedValue,
  706 |   });
  707 | 
  708 |   return {
  709 |     canvasCss: {
  710 |       height: box.height,
  711 |       width: box.width,
  712 |     },
  713 |     label,
  714 |     layout,
  715 |     measuredAt: utcNow(),
  716 |     selectedValue,
  717 |     viewport: page.viewportSize(),
  718 |   };
  719 | };
  720 | 
  721 | const writeEvidenceJson = (name: string, value: unknown) => {
  722 |   writeFileSync(
  723 |     evidenceArtifactPath(name),
  724 |     `${JSON.stringify(value, null, 2)}\n`,
  725 |   );
  726 | };
  727 | 
  728 | const writePngDataUrl = (name: string, dataUrl: string) => {
  729 |   const encoded = dataUrl.replace(/^data:image\/png;base64,/, '');
  730 | 
  731 |   writeFileSync(evidenceScreenshotPath(name), Buffer.from(encoded, 'base64'));
  732 | };
  733 | 
  734 | const captureCanvasBitmap = async (page: Page, name: string) => {
  735 |   markStage(page, 'canvas-bitmap-capture:start', { name });
  736 |   const canvas = page.getByTestId('kaplay-match-result-canvas');
  737 | 
  738 |   try {
  739 |     await expect(canvas).toBeVisible({
  740 |       timeout: SCREENSHOT_CAPTURE_TIMEOUT_MS,
  741 |     });
  742 | 
  743 |     const dataUrl = await canvas.evaluate(
  744 |       (node: HTMLCanvasElement) => node.toDataURL('image/png'),
  745 |       undefined,
  746 |       {
  747 |         timeout: SCREENSHOT_CAPTURE_TIMEOUT_MS,
  748 |       },
  749 |     );
  750 | 
  751 |     writePngDataUrl(name, dataUrl);
  752 |     markStage(page, 'canvas-bitmap-capture:end', { name });
  753 |   } catch (error) {
  754 |     markStage(page, 'canvas-bitmap-capture:failed', {
  755 |       error: errorMessage(error),
```