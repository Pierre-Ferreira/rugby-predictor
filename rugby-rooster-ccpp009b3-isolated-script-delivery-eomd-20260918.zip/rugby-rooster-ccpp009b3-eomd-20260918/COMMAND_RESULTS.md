# CCPP-009B3 Command Results

Date: 2026-09-18
Repository: `/home/pierreferreira/Desktop/rugby-predictor`

## Browser Runs

- Failed launch, not a scenario result:
  `RUGBY_ROOSTER_E2E_EVIDENCE_DIR=/tmp/rugby-rooster-ccpp009b3-run1-20260918T110321Z meteor npm run test:e2e -- kaplay-prediction-preview.spec.ts --workers=1 --retries=0`
  - Exit code: 1
  - Browser scenarios did not execute.

- RUN 1 combined Kaplay baseline:
  `RUGBY_ROOSTER_E2E_EVIDENCE_DIR=/tmp/rugby-rooster-ccpp009b3-run1-20260918T110321Z-escalated meteor npm run test:e2e -- kaplay-prediction-preview.spec.ts --workers=1 --retries=0`
  - Exit code: 1
  - Result: 4 passed, 1 failed.
  - Failure: dirty saved custom prediction revisit rendered Intro and did not
    show `Save revised prediction`.
  - No browser 4xx/5xx responses or failed requests were recorded.

- RUN 2 combined Kaplay verification:
  `RUGBY_ROOSTER_E2E_EVIDENCE_DIR=/tmp/rugby-rooster-ccpp009b3-run2-20260918T112800Z meteor npm run test:e2e -- kaplay-prediction-preview.spec.ts --workers=1 --retries=0`
  - Exit code: 0
  - Result: 5 passed.

- RUN 3 combined Kaplay clean-start confirmation:
  `RUGBY_ROOSTER_E2E_EVIDENCE_DIR=/tmp/rugby-rooster-ccpp009b3-run3-20260918T113100Z meteor npm run test:e2e -- kaplay-prediction-preview.spec.ts --workers=1 --retries=0`
  - Exit code: 0
  - Result: 5 passed.
  - Note: server compiler initially reported a TypeScript diagnostic in the new
    launcher unit test before the JSDoc type correction; browser scenarios
    still passed. Static checks after correction passed.

- Required Standard saved-entry launcher regression:
  `RUGBY_ROOSTER_E2E_EVIDENCE_DIR=/tmp/rugby-rooster-ccpp009b3-standard-20260918T113300Z meteor npm run test:e2e -- predictions.spec.ts --grep "submits valid predictions and revisits the saved Review" --workers=1 --retries=0`
  - Exit code: 1
  - Result: 1 failed.
  - Failure: `Discard changes` remained enabled after successful create before
    the current-entry publication caught up.

- Standard regression rerun after persisted-baseline correction:
  `RUGBY_ROOSTER_E2E_EVIDENCE_DIR=/tmp/rugby-rooster-ccpp009b3-standard-rerun-20260918T113600Z meteor npm run test:e2e -- predictions.spec.ts --grep "submits valid predictions and revisits the saved Review" --workers=1 --retries=0`
  - Exit code: 0
  - Result: 1 passed.

## Unit And Static Checks

- `meteor npm run test:unit -- tests/unit/test-launchers.test.ts tests/unit/playwright-target.test.ts tests/unit/prediction-session.test.ts tests/unit/prediction-session-hook.test.ts`
  - Latest result: 4 files passed, 32 tests passed.

- Changed-file formatting:
  `meteor npm exec prettier -- --check playwright.config.ts scripts/run-playwright-tests.mjs scripts/test-environment.mjs tests/e2e/kaplay-prediction-preview.spec.ts tests/unit/test-launchers.test.ts imports/ui/predictions/predictionSession.ts tests/unit/prediction-session.test.ts tests/unit/prediction-session-hook.test.ts docs/TEMP_009B3_Resume.md docs/AUDIT_009B3_Isolated_Script_Delivery.md docs/CORE_Predictions.md docs/PLATFORM_Prediction_Session.md docs/PLATFORM_Testing.md docs/PLATFORM_Kaplay_Predictions.md docs/MAP_System.md`
  - Latest result: passed.

- `meteor npm run typecheck`
  - Latest result: passed.

- `meteor npm run lint`
  - Latest result: passed.

- `meteor npm run lint:project`
  - Latest result: passed.

- `git diff --check`
  - Latest result: passed.

## Process Cleanup Evidence

- RUN 2 showed a run-owned Rspack listener on `[::1]:3202` after Playwright
  close before the cleanup fix.
- RUN 3, the Standard failed regression, and the Standard rerun recorded
  `owned-process-cleanup-start`, SIGTERM for only run-owned Rspack process-tree
  PIDs, empty `owned-process-cleanup-after-sigterm`, and no 3202 listener in
  `after-owned-process-cleanup`.

