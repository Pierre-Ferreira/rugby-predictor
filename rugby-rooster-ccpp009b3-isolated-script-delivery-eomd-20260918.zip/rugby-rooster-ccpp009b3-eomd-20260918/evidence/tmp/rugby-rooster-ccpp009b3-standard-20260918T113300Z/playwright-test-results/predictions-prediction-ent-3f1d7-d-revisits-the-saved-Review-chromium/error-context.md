# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: predictions.spec.ts >> prediction entry and submission >> submits valid predictions and revisits the saved Review
- Location: tests/e2e/predictions.spec.ts:943:7

# Error details

```
Error: expect(locator).toBeDisabled() failed

Locator:  getByRole('button', { name: 'Discard changes' })
Expected: disabled
Received: enabled
Timeout:  5000ms

Call log:
  - Expect "toBeDisabled" getByRole('button', { name: 'Discard changes' }) with timeout 5000ms
  - waiting for getByRole('button', { name: 'Discard changes' })
    14 × locator resolved to <button type="button" class="focus-ring inline-flex min-h-12 w-full items-center justify-center rounded-md border border-rooster-line bg-white px-5 text-base font-black text-rooster-ink transition hover:bg-rooster-paper sm:w-auto">Discard changes</button>
       - unexpected value "enabled"

```

```yaml
- button "Discard changes"
```

# Test source

```ts
  866  |     await expect(reviewSection(page, 'CARDS')).toHaveCount(0);
  867  |     await expect(reviewSection(page, 'OTHER PREDICTIONS')).toHaveCount(0);
  868  |     await expect(
  869  |       page.getByRole('button', { name: 'Edit first try' }),
  870  |     ).toHaveCount(0);
  871  |     await expect(
  872  |       page.getByRole('button', { name: 'Edit highest-scoring half' }),
  873  |     ).toHaveCount(0);
  874  |     await expect(
  875  |       page.getByRole('button', { name: 'Edit half-time leader' }),
  876  |     ).toHaveCount(0);
  877  |   });
  878  | 
  879  |   test('shows only enabled card rows and deduction copy for partial card enablement', async ({
  880  |     page,
  881  |   }) => {
  882  |     const team1 = uniqueLabel('Griquas');
  883  |     const team2 = uniqueLabel('Griffons');
  884  |     const fixtureId = (
  885  |       await createPublishedFixture(page, {
  886  |         competitionDisplayName: 'Partial Cards Cup',
  887  |         disabledBuiltInQuestionIds: ['yellow-cards'],
  888  |         scheduledKickoffAt: farFutureKickoff(),
  889  |         team1DisplayName: team1,
  890  |         team2DisplayName: team2,
  891  |       })
  892  |     ).fixtureId;
  893  | 
  894  |     await loginAsPlayer(page, 'partial-cards');
  895  |     await gotoLocal(page, predictionPath(fixtureId));
  896  |     await startPrediction(page);
  897  |     await chooseRadio(page, team1);
  898  |     await continueButton(page).click();
  899  | 
  900  |     await teamNumberInput(page, team1, 'tries').fill('2');
  901  |     await teamNumberInput(page, team2, 'tries').fill('1');
  902  |     await continueButton(page).click();
  903  |     await teamNumberInput(page, team1, 'conversions').fill('2');
  904  |     await teamNumberInput(page, team2, 'conversions').fill('1');
  905  |     await continueButton(page).click();
  906  |     await teamNumberInput(page, team1, 'penalty kicks').fill('0');
  907  |     await teamNumberInput(page, team2, 'penalty kicks').fill('0');
  908  |     await continueButton(page).click();
  909  |     await teamNumberInput(page, team1, 'drop goals').fill('0');
  910  |     await teamNumberInput(page, team2, 'drop goals').fill('0');
  911  |     await continueButton(page).click();
  912  | 
  913  |     await expect(
  914  |       page.getByText('Red cards deduct 200 points per difference.'),
  915  |     ).toBeVisible();
  916  |     await expect(
  917  |       page.getByText('Yellow cards deduct 200 points per difference.'),
  918  |     ).toHaveCount(0);
  919  |     await expect(teamNumberInput(page, team1, 'yellow cards')).toHaveCount(0);
  920  |     await expect(teamNumberInput(page, team2, 'yellow cards')).toHaveCount(0);
  921  |     await teamNumberInput(page, team1, 'red cards').fill('1');
  922  |     await teamNumberInput(page, team2, 'red cards').fill('0');
  923  |     await continueButton(page).click();
  924  | 
  925  |     await chooseRadio(page, team1);
  926  |     await continueButton(page).click();
  927  |     await chooseRadio(page, 'Second Half');
  928  |     await continueButton(page).click();
  929  |     await chooseRadio(page, 'Half-time Draw');
  930  |     await page.getByRole('button', { name: 'Review predictions' }).click();
  931  | 
  932  |     await expect(reviewSection(page, 'CARDS')).toContainText(team1);
  933  |     await expect(reviewSection(page, 'CARDS')).toContainText(team2);
  934  |     await expect(reviewSection(page, 'CARDS')).toContainText('Red');
  935  |     await expect(reviewSection(page, 'CARDS').getByText('Yellow')).toHaveCount(
  936  |       0,
  937  |     );
  938  |     await expect(reviewSection(page, 'OTHER PREDICTIONS')).toContainText(
  939  |       'Half-time Draw',
  940  |     );
  941  |   });
  942  | 
  943  |   test('submits valid predictions and revisits the saved Review', async ({
  944  |     page,
  945  |   }) => {
  946  |     const team1 = uniqueLabel('Munster');
  947  |     const team2 = uniqueLabel('Leinster');
  948  |     const fixtureId = (
  949  |       await createPublishedFixture(page, {
  950  |         competitionDisplayName: 'Prediction Cup',
  951  |         scheduledKickoffAt: farFutureKickoff(),
  952  |         team1DisplayName: team1,
  953  |         team2DisplayName: team2,
  954  |         venueDisplayName: 'Kings Park',
  955  |       })
  956  |     ).fixtureId;
  957  | 
  958  |     await loginAsPlayer(page, 'submit');
  959  |     await gotoLocal(page, `/games/${fixtureId}`);
  960  |     await page.getByRole('link', { name: 'Enter prediction' }).click();
  961  |     await fillValidSequentialPrediction(page, { team1, team2 });
  962  |     await submitForm(page, 'Submit prediction');
  963  | 
  964  |     await expect(page.getByRole('status')).toContainText('Prediction saved.');
  965  |     await expect(saveRevisedPredictionButton(page)).toBeVisible();
> 966  |     await expect(discardChangesButton(page)).toBeDisabled();
       |                                              ^ Error: expect(locator).toBeDisabled() failed
  967  |     await expect(
  968  |       page.getByRole('button', { name: /Reload saved entry/i }),
  969  |     ).toHaveCount(0);
  970  |     await expect(reviewSection(page, 'PREDICTED SCORE')).toContainText(team1);
  971  |     await expect(reviewSection(page, 'PREDICTED SCORE')).toContainText('17');
  972  |     await expect(reviewSection(page, 'PREDICTED SCORE')).toContainText('10');
  973  | 
  974  |     await gotoLocal(page, predictionPath(fixtureId));
  975  |     await expect(saveRevisedPredictionButton(page)).toBeVisible({
  976  |       timeout: NAVIGATION_ATTEMPT_TIMEOUT_MS,
  977  |     });
  978  |     await expect(reviewSection(page, 'MATCH RESULT')).toContainText(team1);
  979  |     await reviewSection(page, 'SCORING DETAIL')
  980  |       .getByRole('button', { name: 'Edit' })
  981  |       .click();
  982  |     await expectStep(page, 2);
  983  |     await expect(teamNumberInput(page, team1, 'tries')).toHaveValue('2');
  984  |   });
  985  | 
  986  |   test('discards dirty saved prediction edits only after confirmation', async ({
  987  |     page,
  988  |   }) => {
  989  |     const team1 = uniqueLabel('Boks');
  990  |     const team2 = uniqueLabel('Wallabies');
  991  |     const fixtureId = (
  992  |       await createPublishedFixture(page, {
  993  |         competitionDisplayName: 'Discard Cup',
  994  |         scheduledKickoffAt: farFutureKickoff(),
  995  |         team1DisplayName: team1,
  996  |         team2DisplayName: team2,
  997  |       })
  998  |     ).fixtureId;
  999  | 
  1000 |     await loginAsPlayer(page, 'discard-built-in');
  1001 |     await gotoLocal(page, predictionPath(fixtureId));
  1002 |     await fillValidSequentialPrediction(page, { team1, team2 });
  1003 |     await submitForm(page, 'Submit prediction');
  1004 |     await expect(saveRevisedPredictionButton(page)).toBeVisible({
  1005 |       timeout: NAVIGATION_ATTEMPT_TIMEOUT_MS,
  1006 |     });
  1007 |     await expect(discardChangesButton(page)).toBeDisabled();
  1008 | 
  1009 |     await reviewSection(page, 'SCORING DETAIL')
  1010 |       .getByRole('button', { name: 'Edit' })
  1011 |       .click();
  1012 |     await teamNumberInput(page, team2, 'tries').fill('2');
  1013 |     await page.getByRole('button', { name: 'Return to Review' }).click();
  1014 |     await expect(reviewSection(page, 'PREDICTED SCORE')).toContainText('15');
  1015 |     await expect(discardChangesButton(page)).toBeEnabled();
  1016 | 
  1017 |     await discardChangesButton(page).click();
  1018 |     const discardDialog = page.getByRole('alertdialog', {
  1019 |       name: 'Discard changes?',
  1020 |     });
  1021 |     await expect(discardDialog).toContainText(
  1022 |       'Discard your unsaved changes and restore the last saved prediction?',
  1023 |     );
  1024 | 
  1025 |     await discardDialog.getByRole('button', { name: 'Keep editing' }).click();
  1026 |     await expect(discardDialog).toHaveCount(0);
  1027 |     await expect(reviewSection(page, 'PREDICTED SCORE')).toContainText('15');
  1028 | 
  1029 |     await discardChangesButton(page).click();
  1030 |     await page
  1031 |       .getByRole('alertdialog', { name: 'Discard changes?' })
  1032 |       .getByRole('button', { name: 'Discard changes' })
  1033 |       .click();
  1034 | 
  1035 |     await expect(page.getByRole('status')).toContainText(
  1036 |       'Latest saved prediction loaded. Unsaved values were replaced.',
  1037 |     );
  1038 |     await expect(reviewSection(page, 'PREDICTED SCORE')).toContainText('10');
  1039 |     await expect(reviewSection(page, 'PREDICTED SCORE')).not.toContainText(
  1040 |       '15',
  1041 |     );
  1042 |     await expect(discardChangesButton(page)).toBeDisabled();
  1043 | 
  1044 |     const noWriteResult = await callMeteor<{
  1045 |       readonly revision: number;
  1046 |       readonly status: string;
  1047 |     }>(page, PREDICTION_METHODS.submit, {
  1048 |       expectedRevision: 1,
  1049 |       fixtureId,
  1050 |       prediction: {
  1051 |         ...validPrediction(),
  1052 |         highestScoringHalf: 'first',
  1053 |       },
  1054 |     });
  1055 | 
  1056 |     expect(noWriteResult).toMatchObject({
  1057 |       revision: 2,
  1058 |       status: 'updated',
  1059 |     });
  1060 |   });
  1061 | 
  1062 |   test('answers custom Number and Choice questions in the standard sequence', async ({
  1063 |     browser,
  1064 |     page,
  1065 |   }) => {
  1066 |     const team1 = uniqueLabel('Springboks');
```