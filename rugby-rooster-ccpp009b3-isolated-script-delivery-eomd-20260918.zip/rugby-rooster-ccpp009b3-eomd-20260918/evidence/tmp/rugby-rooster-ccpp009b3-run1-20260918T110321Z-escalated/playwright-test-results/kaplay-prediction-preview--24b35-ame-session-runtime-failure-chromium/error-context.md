# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: kaplay-prediction-preview.spec.ts >> Kaplay prediction preview >> preserves a dirty saved custom prediction through same-session runtime failure
- Location: tests/e2e/kaplay-prediction-preview.spec.ts:868:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('button', { name: 'Save revised prediction' })
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('button', { name: 'Save revised prediction' }) with timeout 15000ms
  - waiting for getByRole('button', { name: 'Save revised prediction' })

```

```yaml
- banner:
  - link "Rugby Rooster":
    - /url: /
  - navigation "Primary navigation":
    - list:
      - listitem:
        - link "Rugby Rooster":
          - /url: /
      - listitem:
        - link "Games":
          - /url: /games
      - listitem:
        - link "Account":
          - /url: /account
      - listitem:
        - button "Sign out"
- main:
  - link "Back to fixture":
    - /url: /games/ueYq2x56tgoH7BmjE
  - text: Published Open before kickoff Dirty Preview Cup
  - heading "Springboks Dirty mu6v44vc9e2f vs All Blacks Dirty mu6v44vc5805" [level=1]
  - paragraph: "Kickoff: 01 Jun 2098, 14:00 SAST"
  - paragraph: Animations
  - paragraph: Match Result preview only. Other prediction steps use the standard experience.
  - group "Animations":
    - button "Off" [pressed]
    - button "On"
  - paragraph: Standard prediction
  - heading "Welcome to Rugby Rooster! 🐓" [level=2]
  - paragraph: You start with 10,000 points and lose points for incorrect predictions. Whoever has the most points at the end of the match wins. It's that easy!
  - heading "Rugby Rooster competition points" [level=3]
  - paragraph: Start at 10,000; prediction errors cause deductions.
  - heading "Predicted rugby match scores" [level=3]
  - paragraph: Derived from your tries, conversions, successful penalty kicks and drop goals.
  - button "Let's predict"
- contentinfo:
  - paragraph: Rugby Rooster account access build.
  - link "Admin":
    - /url: /admin
```

# Test source

```ts
  812  |     await page
  813  |       .getByRole('button', { name: 'Continue without animations' })
  814  |       .first()
  815  |       .click();
  816  |     markStage(page, 'controlled-failure:continue-without-animations');
  817  |     await expect(
  818  |       page.getByRole('radio', { name: team1, exact: true }),
  819  |     ).toBeVisible();
  820  |     await page.waitForTimeout(350);
  821  |     await expect(page.getByTestId('kaplay-match-result-stage')).toHaveCount(0);
  822  | 
  823  |     await gotoLocal(page, predictionPath(fixtureId));
  824  |     await startPrediction(page);
  825  |     await expect(page.getByText('Step 1 of 9')).toBeVisible();
  826  |     markStage(page, 'controlled-failure:revisited-match-result');
  827  | 
  828  |     await page.evaluate(() => {
  829  |       window.__RUGBY_ROOSTER_KAPLAY_PREVIEW_TEST__ = {
  830  |         failOnNextPointer: true,
  831  |       };
  832  |     });
  833  |     markStage(page, 'controlled-failure:pointer-failure-armed');
  834  |     await animationsButton(page, 'On').click();
  835  |     await waitForKaplayReady(page);
  836  |     markStage(page, 'controlled-failure:canvas-choice-click');
  837  |     await clickCanvasChoice(page, 0);
  838  |     await expect(
  839  |       page.getByText(
  840  |         "Animations couldn't continue. Your answers have been kept.",
  841  |       ),
  842  |     ).toBeVisible();
  843  |     await page.screenshot({
  844  |       fullPage: true,
  845  |       path: evidenceScreenshotPath('standard-after-fallback.png'),
  846  |     });
  847  | 
  848  |     await page.evaluate(() => {
  849  |       window.__RUGBY_ROOSTER_KAPLAY_PREVIEW_TEST__ = {};
  850  |     });
  851  |     markStage(page, 'controlled-failure:retry-animations');
  852  |     await page.getByRole('button', { name: 'Retry animations' }).click();
  853  |     await waitForKaplayReady(page);
  854  |     markStage(page, 'controlled-failure:dispatch-webglcontextlost');
  855  |     await page
  856  |       .getByTestId('kaplay-match-result-canvas')
  857  |       .dispatchEvent('webglcontextlost', {
  858  |         bubbles: false,
  859  |         cancelable: true,
  860  |       });
  861  |     await expect(
  862  |       page.getByText(
  863  |         "Animations couldn't continue. Your answers have been kept.",
  864  |       ),
  865  |     ).toBeVisible();
  866  |   });
  867  | 
  868  |   test('preserves a dirty saved custom prediction through same-session runtime failure', async ({
  869  |     page,
  870  |   }) => {
  871  |     const team1 = uniqueLabel('Springboks Dirty');
  872  |     const team2 = uniqueLabel('All Blacks Dirty');
  873  |     const numberPrompt = 'How many scrum penalties will Team 2 concede?';
  874  |     const { fixtureId } = await createPublishedCustomFixture(page, {
  875  |       competitionDisplayName: 'Dirty Preview Cup',
  876  |       scheduledKickoffAt: farFutureKickoff(),
  877  |       team1DisplayName: team1,
  878  |       team2DisplayName: team2,
  879  |     });
  880  | 
  881  |     await loginAsPlayer(page, 'kaplay-dirty-session');
  882  |     await gotoLocal(page, predictionPath(fixtureId));
  883  |     await fillValidCustomSequentialPrediction(
  884  |       page,
  885  |       {
  886  |         team1,
  887  |         team2,
  888  |       },
  889  |       {
  890  |         choiceLabel: 'Forwards',
  891  |         numberPrompt,
  892  |         numberValue: '4',
  893  |       },
  894  |     );
  895  |     await page.getByRole('button', { name: 'Submit prediction' }).click();
  896  |     await expect(page.getByRole('status')).toContainText('Prediction saved.');
  897  | 
  898  |     const savedEntry = await currentUserPredictionEntry(page, fixtureId);
  899  |     const savedRevision = savedEntry?.revision;
  900  | 
  901  |     expect(savedRevision).toBeGreaterThan(0);
  902  |     expect(savedEntry?.prediction.highestScoringHalf).toBe('second');
  903  |     expect(savedEntry?.prediction.customAnswers).toMatchObject({
  904  |       'player-band': 'forwards',
  905  |       'scrum-pressure': 4,
  906  |     });
  907  |     markStage(page, 'dirty-session:saved-entry-created', {
  908  |       savedRevision,
  909  |     });
  910  | 
  911  |     await gotoLocal(page, predictionPath(fixtureId));
> 912  |     await expect(saveRevisedPredictionButton(page)).toBeVisible({
       |                                                     ^ Error: expect(locator).toBeVisible() failed
  913  |       timeout: NAVIGATION_ATTEMPT_TIMEOUT_MS,
  914  |     });
  915  | 
  916  |     await reviewSection(page, 'OTHER PREDICTIONS')
  917  |       .getByRole('button', { name: 'Edit highest-scoring half' })
  918  |       .click();
  919  |     await expectStep(page, 7, 10);
  920  |     await chooseRadio(page, 'First Half');
  921  |     await page.getByRole('button', { name: 'Return to Review' }).click();
  922  | 
  923  |     await reviewSection(page, 'CUSTOM QUESTIONS')
  924  |       .getByRole('button', { name: 'Edit custom question' })
  925  |       .first()
  926  |       .click();
  927  |     await expectStep(page, 9, 10);
  928  |     await page
  929  |       .getByRole('spinbutton', { name: `${numberPrompt} answer` })
  930  |       .fill('6');
  931  |     await page.getByRole('button', { name: 'Return to Review' }).click();
  932  | 
  933  |     await reviewSection(page, 'CUSTOM QUESTIONS')
  934  |       .getByRole('button', { name: 'Edit custom question' })
  935  |       .nth(1)
  936  |       .click();
  937  |     await expectStep(page, 10, 10);
  938  |     await chooseRadio(page, 'Backs');
  939  |     await page.getByRole('button', { name: 'Return to Review' }).click();
  940  | 
  941  |     await expect(reviewSection(page, 'OTHER PREDICTIONS')).toContainText(
  942  |       'First half',
  943  |     );
  944  |     await expect(reviewSection(page, 'CUSTOM QUESTIONS')).toContainText('6');
  945  |     await expect(reviewSection(page, 'CUSTOM QUESTIONS')).toContainText(
  946  |       'Backs',
  947  |     );
  948  |     markStage(page, 'dirty-session:unsaved-review-edits-ready');
  949  | 
  950  |     await reviewSection(page, 'MATCH RESULT')
  951  |       .getByRole('button', { name: 'Edit' })
  952  |       .click();
  953  |     await expectStep(page, 1, 10);
  954  |     await expect(
  955  |       page.getByRole('button', { name: 'Return to Review' }),
  956  |     ).toBeVisible();
  957  |     await expect(
  958  |       page.getByRole('radio', { exact: true, name: team1 }),
  959  |     ).toBeChecked();
  960  | 
  961  |     const navigationProbe = createMainFrameNavigationProbe(page);
  962  | 
  963  |     navigationProbe.arm();
  964  |     markStage(page, 'dirty-session:protected-segment-armed');
  965  |     await animationsButton(page, 'On').click();
  966  |     await expect(
  967  |       page.getByRole('button', { name: 'Return to Review' }),
  968  |     ).toBeVisible();
  969  |     await waitForKaplayReady(page);
  970  |     markStage(page, 'dirty-session:canvas-choice-click');
  971  |     await clickCanvasChoice(page, 0);
  972  |     await expect(page.getByTestId('kaplay-match-result-picked')).toContainText(
  973  |       `You picked ${team1}`,
  974  |     );
  975  | 
  976  |     markStage(page, 'dirty-session:dispatch-webglcontextlost');
  977  |     await page
  978  |       .getByTestId('kaplay-match-result-canvas')
  979  |       .dispatchEvent('webglcontextlost', {
  980  |         bubbles: false,
  981  |         cancelable: true,
  982  |       });
  983  |     await expect(
  984  |       page.getByText(
  985  |         "Animations couldn't continue. Your answers have been kept.",
  986  |       ),
  987  |     ).toBeVisible();
  988  |     await expect(page.getByTestId('kaplay-match-result-stage')).toHaveCount(0);
  989  |     await expectStep(page, 1, 10);
  990  |     await expect(
  991  |       page.getByRole('button', { name: 'Return to Review' }),
  992  |     ).toBeVisible();
  993  |     await expect(
  994  |       page.getByRole('radio', { exact: true, name: team1 }),
  995  |     ).toBeChecked();
  996  |     expect(
  997  |       navigationProbe.urls(),
  998  |       'Kaplay dirty-session preservation segment should not trigger a page reload.',
  999  |     ).toEqual([]);
  1000 | 
  1001 |     const entryAfterFailure = await currentUserPredictionEntry(page, fixtureId);
  1002 | 
  1003 |     expect(entryAfterFailure?.revision).toBe(savedRevision);
  1004 |     expect(entryAfterFailure?.prediction.highestScoringHalf).toBe('second');
  1005 |     expect(entryAfterFailure?.prediction.customAnswers).toMatchObject({
  1006 |       'player-band': 'forwards',
  1007 |       'scrum-pressure': 4,
  1008 |     });
  1009 |     markStage(page, 'dirty-session:persisted-entry-unchanged-after-failure');
  1010 | 
  1011 |     await animationsButton(page, 'Off').click();
  1012 |     await page.getByRole('button', { name: 'Return to Review' }).click();
```