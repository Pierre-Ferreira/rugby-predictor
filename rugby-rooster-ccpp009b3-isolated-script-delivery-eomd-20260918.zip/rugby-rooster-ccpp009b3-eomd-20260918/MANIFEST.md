# CCPP-009B3 Archive Manifest

This archive contains a review copy of the Rugby Rooster CCPP-009B3 closeout.

## Included Repository Context

- `AGENTS.md`, `README.md`, `package.json`, `package-lock.json`
- Playwright and Rspack config.
- Isolated test launchers and target guards.
- Focused Kaplay and Standard prediction browser specs.
- Prediction session source and relevant UI/runtime context.
- Focused unit tests for launchers, target guard, session reducer, and session
  hook lifecycle.
- Updated CCPP audit, checkpoint, platform, map, and core prediction docs.

## Included Evidence

Sanitized copies under `evidence/tmp/...` include:

- launch manifests and safe environment summaries;
- Playwright stdout/stderr and runner JSONL output;
- process/listener snapshots and process events;
- browser JSON timelines emitted by the Kaplay spec;
- screenshots and error contexts from failures;
- scenario screenshots from passing Kaplay runs.

Raw `trace.zip` and `video.webm` artifacts are intentionally excluded.

## Excluded

- Dependencies and build outputs such as `node_modules`, `.meteor/local*`,
  local Rspack build chunks/assets, and Playwright reports.
- Raw traces, videos, cookies, tokens, private settings, and unrelated archives.
- Repository originals were copied only; they were not removed.

