# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: kaplay-prediction-preview.spec.ts >> Kaplay prediction preview >> keeps canvas coordinates synchronized across desktop compact desktop resizing
- Location: tests/e2e/kaplay-prediction-preview.spec.ts:1142:7

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: page.screenshot: Target page, context or browser has been closed
```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - banner [ref=f2e4]:
    - generic [ref=f2e5]:
      - link "Rugby Rooster" [ref=f2e6] [cursor=pointer]:
        - /url: /
        - generic [aria-hidden] [ref=f2e7]: RR
      - navigation "Primary navigation" [ref=f2e9]:
        - list [ref=f2e10]:
          - listitem [ref=f2e11]:
            - link "Rugby Rooster" [ref=f2e12] [cursor=pointer]:
              - /url: /
          - listitem [ref=f2e13]:
            - link "Games" [ref=f2e14] [cursor=pointer]:
              - /url: /games
          - listitem [ref=f2e15]:
            - link "Account" [ref=f2e16] [cursor=pointer]:
              - /url: /account
          - listitem [ref=f2e17]:
            - button "Sign out" [ref=f2e19] [cursor=pointer]
  - main [ref=f2e20]:
    - generic [ref=f2e21]:
      - link "Back to fixture" [ref=f2e22] [cursor=pointer]:
        - /url: /games/wYKhuB3R2Yu4CAsrh
      - generic [ref=f2e23]:
        - generic [ref=f2e24]: Published
        - generic [ref=f2e25]: Open before kickoff
        - generic [ref=f2e26]: kaplay-resize-sync Cup
      - heading "Cape Town Longform Rugby Football Club mu8et3w5d3d2 XV vs Johannesburg Longform Rugby Football Club mu8et3w56fd2 XV" [level=1] [ref=f2e27]
      - paragraph [ref=f2e28]: "Kickoff: 01 Jun 2098, 14:00 SAST"
    - generic [ref=f2e29]:
      - generic [ref=f2e31]:
        - generic [ref=f2e32]:
          - paragraph [ref=f2e33]: Animations
          - paragraph [ref=f2e34]: Animated Match Result is available. Other prediction steps currently use the standard experience.
        - group "Animations" [ref=f2e35]:
          - button "Off" [ref=f2e36] [cursor=pointer]
          - button "On" [pressed] [ref=f2e37] [cursor=pointer]
      - generic [ref=f2e38]:
        - group "Step 1 of 9" [ref=f2e39]
        - generic [ref=f2e50]:
          - paragraph [ref=f2e51]: Step 1 of 9
          - heading "TIME TO PICK A SIDE!" [level=2] [ref=f2e52]
          - paragraph [ref=f2e53]: Who gets the result?
          - paragraph [ref=f2e54]: Get the result wrong and lose 5,000 points—half your starting score. Pick carefully!
        - generic "TIME TO PICK A SIDE!" [ref=f2e56]
        - group "TIME TO PICK A SIDE!" [ref=f2e57]:
          - generic [ref=f2e58]: Match Result animation choices
          - generic [ref=f2e59]:
            - radio "Cape Town Longform Rugby Football Club mu8et3w5d3d2 XV" [ref=f2e60]
            - text: Cape Town Longform Rugby Football Club mu8et3w5d3d2 XV
          - generic [ref=f2e61]:
            - radio "Johannesburg Longform Rugby Football Club mu8et3w56fd2 XV" [ref=f2e62]
            - text: Johannesburg Longform Rugby Football Club mu8et3w56fd2 XV
          - generic [ref=f2e63]:
            - radio "Draw" [ref=f2e64]
            - text: Draw
        - generic [ref=f2e65]:
          - button "Back" [ref=f2e66] [cursor=pointer]
          - button "Continue" [ref=f2e68] [cursor=pointer]
  - contentinfo [ref=f2e69]:
    - generic [ref=f2e70]:
      - paragraph [ref=f2e71]: Rugby Rooster account access build.
      - link "Admin" [ref=f2e72] [cursor=pointer]:
        - /url: /admin
```

# Test source

```ts
  1068 |     await expect(
  1069 |       page.getByText('Standard prediction', { exact: true }),
  1070 |     ).toBeVisible();
  1071 |     await expect(page.getByTestId('kaplay-match-result-stage')).toHaveCount(0);
  1072 |     await expect
  1073 |       .poll(() =>
  1074 |         page.evaluate(
  1075 |           (key) => window.localStorage.getItem(key),
  1076 |           animationPreferenceStorageKey,
  1077 |         ),
  1078 |       )
  1079 |       .toBeNull();
  1080 |     await expect
  1081 |       .poll(() =>
  1082 |         page.evaluate(() => window.__RUGBY_ROOSTER_KAPLAY_IMPORT_COUNT__ ?? 0),
  1083 |       )
  1084 |       .toBe(0);
  1085 | 
  1086 |     markStage(page, 'default-access:start-prediction');
  1087 |     await startPrediction(page);
  1088 |     await expect(page.getByText('Step 1 of 9')).toBeVisible();
  1089 |     await waitForKaplayReady(page);
  1090 |     await page.screenshot({
  1091 |       fullPage: true,
  1092 |       path: evidenceScreenshotPath('desktop-default-match-result-preview.png'),
  1093 |     });
  1094 | 
  1095 |     markStage(page, 'default-access:canvas-choice-click');
  1096 |     await startCanvasRecording(page);
  1097 |     await page.waitForTimeout(300);
  1098 |     await clickCanvasChoice(page, 1);
  1099 |     await expect(page.getByTestId('kaplay-match-result-picked')).toContainText(
  1100 |       `You picked ${team2}`,
  1101 |     );
  1102 |     await page.waitForTimeout(2_000);
  1103 |     await stopCanvasRecording(page, 'match-result-shove-normal-speed.webm');
  1104 |     await expect(
  1105 |       page.getByRole('radio', { name: team2, exact: true }),
  1106 |     ).toHaveAttribute('aria-checked', 'true');
  1107 |     await page.screenshot({
  1108 |       fullPage: true,
  1109 |       path: evidenceScreenshotPath('desktop-default-match-result-selected.png'),
  1110 |     });
  1111 | 
  1112 |     markStage(page, 'default-access:animations-off');
  1113 |     await animationsButton(page, 'Off').click();
  1114 |     await expect(
  1115 |       page.getByRole('radio', { name: team2, exact: true }),
  1116 |     ).toBeChecked();
  1117 | 
  1118 |     markStage(page, 'default-access:continue-to-standard-step');
  1119 |     await continueButton(page).click();
  1120 |     await expect(page.getByText('Step 2 of 9')).toBeVisible();
  1121 |     await expect(page.getByTestId('kaplay-match-result-stage')).toHaveCount(0);
  1122 |     await expect(
  1123 |       page.getByRole('spinbutton', { name: `${team1} tries` }),
  1124 |     ).toBeVisible();
  1125 | 
  1126 |     markStage(page, 'default-access:back-to-match-result-off');
  1127 |     await page.getByRole('button', { name: 'Back' }).click();
  1128 |     await expect(page.getByText('Step 1 of 9')).toBeVisible();
  1129 |     await expect(page.getByTestId('kaplay-match-result-stage')).toHaveCount(0);
  1130 |     await expect(
  1131 |       page.getByRole('radio', { name: team2, exact: true }),
  1132 |     ).toBeChecked();
  1133 | 
  1134 |     markStage(page, 'default-access:animations-on-again');
  1135 |     await animationsButton(page, 'On').click();
  1136 |     await waitForKaplayReady(page);
  1137 |     await expect(page.getByTestId('kaplay-match-result-picked')).toContainText(
  1138 |       `You picked ${team2}`,
  1139 |     );
  1140 |   });
  1141 | 
  1142 |   test('keeps canvas coordinates synchronized across desktop compact desktop resizing', async ({
  1143 |     page,
  1144 |   }) => {
  1145 |     await page.setViewportSize({ height: 900, width: 1280 });
  1146 |     const measurements: BrowserEvidenceEntry[] = [];
  1147 |     const longTeam1 = `${uniqueLabel('Cape Town Longform Rugby Football Club')} XV`;
  1148 |     const longTeam2 = `${uniqueLabel('Johannesburg Longform Rugby Football Club')} XV`;
  1149 |     const { fixtureId, team1, team2 } = await createPredictionAtMatchResult(
  1150 |       page,
  1151 |       'kaplay-resize-sync',
  1152 |       {
  1153 |         team1: longTeam1,
  1154 |         team2: longTeam2,
  1155 |       },
  1156 |     );
  1157 | 
  1158 |     await waitForKaplayReady(page);
  1159 | 
  1160 |     const collectResizeEvidence = async (
  1161 |       label: string,
  1162 |       screenshotName: string,
  1163 |       cropName: string,
  1164 |       observedPointerResult: string | null,
  1165 |     ) => {
  1166 |       const measurement = await collectKaplayLayoutEvidence(page, label);
  1167 | 
> 1168 |       await page.screenshot({
       |                  ^ Error: page.screenshot: Target page, context or browser has been closed
  1169 |         fullPage: true,
  1170 |         path: evidenceScreenshotPath(screenshotName),
  1171 |       });
  1172 |       await screenshotCanvasCrop(page, cropName);
  1173 | 
  1174 |       measurements.push({
  1175 |         ...measurement,
  1176 |         observedPointerResult,
  1177 |       });
  1178 | 
  1179 |       for (const choice of measurement.layout.choices) {
  1180 |         expect(choice.labelCssFontSize).toBeGreaterThanOrEqual(15.99);
  1181 |         expect(choice.targetCssHeight).toBeGreaterThanOrEqual(43.99);
  1182 |       }
  1183 | 
  1184 |       expect(measurement.layout.viewport.engine).toEqual({
  1185 |         height: measurement.layout.stage.height,
  1186 |         width: measurement.layout.stage.width,
  1187 |       });
  1188 |       expect(measurement.layout.viewport.renderedContentBounds).not.toBeNull();
  1189 |     };
  1190 | 
  1191 |     await collectResizeEvidence(
  1192 |       'initial desktop choices',
  1193 |       'resize-sync-desktop-initial.png',
  1194 |       'resize-sync-desktop-initial-crop.png',
  1195 |       null,
  1196 |     );
  1197 | 
  1198 |     markStage(page, 'resize-sync:desktop-pointer-team2');
  1199 |     await clickCanvasChoice(page, 1);
  1200 |     await expect(page.getByTestId('kaplay-match-result-picked')).toContainText(
  1201 |       `You picked ${team2}`,
  1202 |     );
  1203 |     await page.getByRole('button', { name: 'Change my selection' }).click();
  1204 |     await waitForHitTestableChoices(page);
  1205 | 
  1206 |     markStage(page, 'resize-sync:to-390');
  1207 |     await page.setViewportSize({ height: 760, width: 390 });
  1208 |     await waitForHitTestableChoices(page);
  1209 |     await collectResizeEvidence(
  1210 |       'compact 390 choices after desktop resize',
  1211 |       'resize-sync-compact-390.png',
  1212 |       'resize-sync-compact-390-crop.png',
  1213 |       team2,
  1214 |     );
  1215 | 
  1216 |     markStage(page, 'resize-sync:compact-390-draw-pointer');
  1217 |     await clickCanvasChoice(page, 2);
  1218 |     await expect(page.getByTestId('kaplay-match-result-picked')).toContainText(
  1219 |       'You picked Draw',
  1220 |     );
  1221 |     await page.getByRole('button', { name: 'Change my selection' }).click();
  1222 |     await waitForHitTestableChoices(page);
  1223 | 
  1224 |     markStage(page, 'resize-sync:to-360');
  1225 |     await page.setViewportSize({ height: 760, width: 360 });
  1226 |     await waitForHitTestableChoices(page);
  1227 |     await collectResizeEvidence(
  1228 |       'compact 360 choices after compact resize',
  1229 |       'resize-sync-compact-360.png',
  1230 |       'resize-sync-compact-360-crop.png',
  1231 |       'draw',
  1232 |     );
  1233 | 
  1234 |     markStage(page, 'resize-sync:compact-360-team1-pointer');
  1235 |     await clickCanvasChoice(page, 0);
  1236 |     await expect(page.getByTestId('kaplay-match-result-picked')).toContainText(
  1237 |       `You picked ${team1}`,
  1238 |     );
  1239 |     await page.getByRole('button', { name: 'Change my selection' }).click();
  1240 |     await waitForHitTestableChoices(page);
  1241 | 
  1242 |     markStage(page, 'resize-sync:return-desktop');
  1243 |     await page.setViewportSize({ height: 900, width: 1280 });
  1244 |     await waitForHitTestableChoices(page);
  1245 |     await collectResizeEvidence(
  1246 |       'desktop choices after compact return',
  1247 |       'resize-sync-desktop-returned.png',
  1248 |       'resize-sync-desktop-returned-crop.png',
  1249 |       team1,
  1250 |     );
  1251 | 
  1252 |     markStage(page, 'resize-sync:desktop-keyboard-team2');
  1253 |     await page.getByRole('radio', { name: team2, exact: true }).focus();
  1254 |     await page.keyboard.press('Space');
  1255 |     await expect(page.getByTestId('kaplay-match-result-picked')).toContainText(
  1256 |       `You picked ${team2}`,
  1257 |     );
  1258 |     await expect(
  1259 |       page.getByRole('radio', { name: team2, exact: true }),
  1260 |     ).toHaveAttribute('aria-checked', 'true');
  1261 | 
  1262 |     await page.getByRole('button', { name: 'Change my selection' }).click();
  1263 |     await waitForHitTestableChoices(page);
  1264 |     markStage(page, 'resize-sync:record-resize-during-shove');
  1265 |     await startCanvasRecording(page);
  1266 |     await clickCanvasChoice(page, 2);
  1267 |     await page.setViewportSize({ height: 760, width: 390 });
  1268 |     await expect(page.getByTestId('kaplay-match-result-picked')).toContainText(
```