# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: kaplay-prediction-preview.spec.ts >> Kaplay prediction preview >> uses Standard when reduced motion blocks automatic activation
- Location: tests/e2e/kaplay-prediction-preview.spec.ts:1373:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByTestId('kaplay-match-result-canvas')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByTestId('kaplay-match-result-canvas') with timeout 5000ms
  - waiting for getByTestId('kaplay-match-result-canvas')

```

```yaml
- banner:
  - link "Rugby Rooster":
    - /url: /
  - navigation "Primary navigation":
    - list:
      - listitem:
        - link "Rugby Rooster":
          - /url: /
      - listitem:
        - link "Games":
          - /url: /games
      - listitem:
        - link "Account":
          - /url: /account
      - listitem:
        - button "Sign out"
- main:
  - link "Back to fixture":
    - /url: /games/KRrRE9hPD8X93Nwzf
  - text: Published Open before kickoff kaplay-reduced-motion Cup
  - heading "Cape Town Very Long Club Name mu8eup6k302e XV vs Johannesburg Equally Long Club Name mu8eup6kd16e XV" [level=1]
  - paragraph: "Kickoff: 01 Jun 2098, 14:00 SAST"
  - paragraph: Animations
  - paragraph: Animated Match Result is available. Other prediction steps currently use the standard experience.
  - group "Animations":
    - button "Off"
    - button "On" [pressed]
  - alert:
    - paragraph: Animations couldn't continue. Your answers have been kept.
    - button "Retry animations"
  - group "Step 1 of 9"
  - paragraph: Step 1 of 9
  - heading "TIME TO PICK A SIDE!" [level=2]
  - paragraph: Who gets the result?
  - paragraph: Get the result wrong and lose 5,000 points—half your starting score. Pick carefully!
  - paragraph: "Choices: Cape Town Very Long Club Name mu8eup6k302e XV, Johannesburg Equally Long Club Name mu8eup6kd16e XV, or Draw."
  - group "Who do you think will win?":
    - text: Who do you think will win?
    - radio "Cape Town Very Long Club Name mu8eup6k302e XV"
    - text: Cape Town Very Long Club Name mu8eup6k302e XV
    - radio "Johannesburg Equally Long Club Name mu8eup6kd16e XV"
    - text: Johannesburg Equally Long Club Name mu8eup6kd16e XV
    - radio "Draw"
    - text: Draw
  - button "Back"
  - button "Continue"
- contentinfo:
  - paragraph: Rugby Rooster account access build.
  - link "Admin":
    - /url: /admin
```

# Test source

```ts
  448 |   details: {
  449 |     readonly competitionDisplayName: string;
  450 |     readonly scheduledKickoffAt: string;
  451 |     readonly team1DisplayName: string;
  452 |     readonly team2DisplayName: string;
  453 |   },
  454 | ) => {
  455 |   const defaultConfig = defaultFixturePredictionQuestionConfig();
  456 | 
  457 |   return callMeteor<{ readonly fixtureId: string }>(
  458 |     setupPage,
  459 |     TEST_FIXTURE_METHODS.createPublished,
  460 |     {
  461 |       details,
  462 |       questionConfig: {
  463 |         ...defaultConfig,
  464 |         optionalStandardQuestions: defaultConfig.optionalStandardQuestions.map(
  465 |           (question) =>
  466 |             question.id === 'first-try'
  467 |               ? {
  468 |                   ...question,
  469 |                   enabled: false,
  470 |                 }
  471 |               : question,
  472 |         ),
  473 |         customQuestions: [
  474 |           {
  475 |             answerType: 'number' as const,
  476 |             banter: 'Set-piece heat check.',
  477 |             countingDefinition:
  478 |               'Scrum penalties awarded against Team 2 during regulation match time.',
  479 |             deductionPerUnit: 25,
  480 |             id: 'scrum-pressure',
  481 |             max: 12,
  482 |             min: 0,
  483 |             order: 1,
  484 |             prompt: 'How many scrum penalties will Team 2 concede?',
  485 |           },
  486 |           {
  487 |             answerType: 'choice' as const,
  488 |             countingDefinition:
  489 |               'The official player of the match positional group announced after full-time.',
  490 |             id: 'player-band',
  491 |             incorrectDeduction: 75,
  492 |             options: [
  493 |               { id: 'backs', label: 'Backs' },
  494 |               { id: 'forwards', label: 'Forwards' },
  495 |             ],
  496 |             order: 2,
  497 |             prompt: 'Which group produces the player of the match?',
  498 |           },
  499 |         ],
  500 |       },
  501 |     },
  502 |   );
  503 | };
  504 | 
  505 | const farFutureKickoff = () =>
  506 |   new Date(Date.UTC(2098, 5, 1, 12, 0, 0)).toISOString();
  507 | 
  508 | const predictionPath = (fixtureId: string) => `/games/${fixtureId}/predict`;
  509 | 
  510 | const startPrediction = async (page: Page) => {
  511 |   await page.getByRole('button', { name: "Let's predict" }).click();
  512 | };
  513 | 
  514 | const continueButton = (page: Page) =>
  515 |   page.getByRole('button', { exact: true, name: 'Continue' });
  516 | 
  517 | const chooseVisibleRadio = async (page: Page, name: string) => {
  518 |   const radio = page.getByRole('radio', { exact: true, name });
  519 | 
  520 |   await expect(radio).toBeVisible();
  521 |   await radio.check();
  522 | };
  523 | 
  524 | const teamNumberInput = (page: Page, teamName: string, fieldName: string) =>
  525 |   page.getByRole('spinbutton', { name: `${teamName} ${fieldName}` });
  526 | 
  527 | const reviewSection = (page: Page, label: string) =>
  528 |   page.getByRole('group', { name: `Review ${label}` });
  529 | 
  530 | const expectStep = async (page: Page, current: number, total = 9) => {
  531 |   await expect(page.getByText(`Step ${current} of ${total}`)).toBeVisible({
  532 |     timeout: NAVIGATION_ATTEMPT_TIMEOUT_MS,
  533 |   });
  534 | };
  535 | 
  536 | const saveRevisedPredictionButton = (page: Page) =>
  537 |   page.getByRole('button', { name: 'Save revised prediction' });
  538 | 
  539 | const animationsButton = (page: Page, name: 'Off' | 'On') =>
  540 |   page.getByRole('button', { exact: true, name });
  541 | 
  542 | const waitForKaplayReady = async (page: Page) => {
  543 |   markStage(page, 'kaplay-ready:wait-start');
  544 |   await expect(page.getByTestId('kaplay-match-result-stage')).toBeVisible({
  545 |     timeout: NAVIGATION_ATTEMPT_TIMEOUT_MS,
  546 |   });
  547 |   await expect(page.getByText('Loading animation preview.')).toHaveCount(0);
> 548 |   await expect(page.getByTestId('kaplay-match-result-canvas')).toBeVisible();
      |                                                                ^ Error: expect(locator).toBeVisible() failed
  549 |   markStage(page, 'kaplay-ready:success');
  550 | };
  551 | 
  552 | const waitForKaplayDebugLayout = async (page: Page) => {
  553 |   await page.waitForFunction(
  554 |     () => {
  555 |       const layout = window.__RUGBY_ROOSTER_KAPLAY_LAST_LAYOUT__;
  556 | 
  557 |       return (
  558 |         Boolean(layout) &&
  559 |         Array.isArray(layout?.choices) &&
  560 |         layout.choices.length > 0 &&
  561 |         layout.synchronized === true &&
  562 |         layout.viewport.renderedContentBounds !== null &&
  563 |         layout.viewport.engine.width === layout.stage.width &&
  564 |         layout.viewport.engine.height === layout.stage.height
  565 |       );
  566 |     },
  567 |     undefined,
  568 |     { timeout: NAVIGATION_ATTEMPT_TIMEOUT_MS },
  569 |   );
  570 | };
  571 | 
  572 | const waitForHitTestableChoices = async (page: Page) => {
  573 |   await waitForKaplayDebugLayout(page);
  574 |   await page.waitForFunction(
  575 |     () => {
  576 |       const layout = window.__RUGBY_ROOSTER_KAPLAY_LAST_LAYOUT__;
  577 | 
  578 |       return (
  579 |         layout?.synchronized === true &&
  580 |         layout.selectedChoice === null &&
  581 |         layout.choices.length === 3 &&
  582 |         layout.choices.every((choice) => choice.hitTestable)
  583 |       );
  584 |     },
  585 |     undefined,
  586 |     { timeout: NAVIGATION_ATTEMPT_TIMEOUT_MS },
  587 |   );
  588 | };
  589 | 
  590 | const retryIfAnimationFailureIsVisible = async (page: Page) => {
  591 |   const retryButton = page.getByRole('button', { name: 'Retry animations' });
  592 | 
  593 |   if (
  594 |     await retryButton
  595 |       .isVisible({
  596 |         timeout: 1_000,
  597 |       })
  598 |       .catch(() => false)
  599 |   ) {
  600 |     await retryButton.click();
  601 |   }
  602 | };
  603 | 
  604 | const clickCanvasChoice = async (page: Page, choiceIndex: 0 | 1 | 2) => {
  605 |   const canvas = page.getByTestId('kaplay-match-result-canvas');
  606 |   const box = await canvas.boundingBox();
  607 | 
  608 |   if (!box) {
  609 |     throw new Error('Kaplay canvas is not visible.');
  610 |   }
  611 | 
  612 |   await waitForKaplayDebugLayout(page);
  613 |   const choice = await page.evaluate((index) => {
  614 |     const layout = window.__RUGBY_ROOSTER_KAPLAY_LAST_LAYOUT__;
  615 |     const projectedChoice = layout?.choices[index];
  616 | 
  617 |     if (!layout || !projectedChoice) {
  618 |       throw new Error('Kaplay choice layout is not available.');
  619 |     }
  620 | 
  621 |     if (!projectedChoice.hitTestable) {
  622 |       throw new Error('Kaplay choice layout is not currently hit-testable.');
  623 |     }
  624 | 
  625 |     return {
  626 |       centerX: projectedChoice.rect.x + projectedChoice.rect.width / 2,
  627 |       centerY: projectedChoice.rect.y + projectedChoice.rect.height / 2,
  628 |       content: layout.viewport.renderedContentBounds,
  629 |       stageHeight: layout.stage.height,
  630 |       stageWidth: layout.stage.width,
  631 |     };
  632 |   }, choiceIndex);
  633 | 
  634 |   if (!choice.content) {
  635 |     throw new Error('Kaplay rendered content bounds are not available.');
  636 |   }
  637 | 
  638 |   await canvas.click({
  639 |     position: {
  640 |       x:
  641 |         choice.content.x +
  642 |         (choice.centerX / choice.stageWidth) * choice.content.width,
  643 |       y:
  644 |         choice.content.y +
  645 |         (choice.centerY / choice.stageHeight) * choice.content.height,
  646 |     },
  647 |   });
  648 | };
```