# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: kaplay-prediction-preview.spec.ts >> Kaplay prediction preview >> keeps canvas coordinates synchronized across desktop compact desktop resizing
- Location: tests/e2e/kaplay-prediction-preview.spec.ts:1148:7

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.boundingBox: Target page, context or browser has been closed
```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - banner [ref=f2e4]:
    - generic [ref=f2e5]:
      - link "Rugby Rooster" [ref=f2e6] [cursor=pointer]:
        - /url: /
        - generic [aria-hidden] [ref=f2e7]: RR
      - navigation "Primary navigation" [ref=f2e9]:
        - list [ref=f2e10]:
          - listitem [ref=f2e11]:
            - link "Rugby Rooster" [ref=f2e12] [cursor=pointer]:
              - /url: /
          - listitem [ref=f2e13]:
            - link "Games" [ref=f2e14] [cursor=pointer]:
              - /url: /games
          - listitem [ref=f2e15]:
            - link "Account" [ref=f2e16] [cursor=pointer]:
              - /url: /account
          - listitem [ref=f2e17]:
            - button "Sign out" [ref=f2e19] [cursor=pointer]
  - main [ref=f2e20]:
    - generic [ref=f2e21]:
      - link "Back to fixture" [ref=f2e22] [cursor=pointer]:
        - /url: /games/bWexfbMvuFFwaE6ik
      - generic [ref=f2e23]:
        - generic [ref=f2e24]: Published
        - generic [ref=f2e25]: Open before kickoff
        - generic [ref=f2e26]: kaplay-resize-sync Cup
      - heading "Cape Town Longform Rugby Football Club mu8kx2kn62c8 XV vs Johannesburg Longform Rugby Football Club mu8kx2knb4cf XV" [level=1] [ref=f2e27]
      - paragraph [ref=f2e28]: "Kickoff: 01 Jun 2098, 14:00 SAST"
    - generic [ref=f2e29]:
      - generic [ref=f2e31]:
        - generic [ref=f2e32]:
          - paragraph [ref=f2e33]: Animations
          - paragraph [ref=f2e34]: Animated Match Result is available. Other prediction steps currently use the standard experience.
        - group "Animations" [ref=f2e35]:
          - button "Off" [ref=f2e36] [cursor=pointer]
          - button "On" [pressed] [ref=f2e37] [cursor=pointer]
      - generic [ref=f2e38]:
        - group "Step 1 of 9" [ref=f2e39]
        - generic [ref=f2e50]:
          - paragraph [ref=f2e51]: Step 1 of 9
          - heading "CALL IT!" [level=2] [ref=f2e52]
          - paragraph [ref=f2e53]: Who's taking this one?
          - paragraph [ref=f2e54]: Get the result wrong and lose 5,000 points—half your starting score. Pick carefully!
        - generic "CALL IT!" [ref=f2e56]
        - group "CALL IT!" [ref=f2e57]:
          - generic [ref=f2e58]: Match Result animation choices
          - generic [ref=f2e59]:
            - radio "Cape Town Longform Rugby Football Club mu8kx2kn62c8 XV" [ref=f2e60]
            - text: Cape Town Longform Rugby Football Club mu8kx2kn62c8 XV
          - generic [ref=f2e61]:
            - radio "Johannesburg Longform Rugby Football Club mu8kx2knb4cf XV" [ref=f2e62]
            - text: Johannesburg Longform Rugby Football Club mu8kx2knb4cf XV
          - generic [ref=f2e63]:
            - radio "Draw" [ref=f2e64]
            - text: Draw
        - generic [ref=f2e65]:
          - button "Back" [ref=f2e66] [cursor=pointer]
          - button "Continue" [ref=f2e68] [cursor=pointer]
  - contentinfo [ref=f2e69]:
    - generic [ref=f2e70]:
      - paragraph [ref=f2e71]: Rugby Rooster account access build.
      - link "Admin" [ref=f2e72] [cursor=pointer]:
        - /url: /admin
```

# Test source

```ts
  507 |   new Date(Date.UTC(2098, 5, 1, 12, 0, 0)).toISOString();
  508 | 
  509 | const predictionPath = (fixtureId: string) => `/games/${fixtureId}/predict`;
  510 | 
  511 | const startPrediction = async (page: Page) => {
  512 |   await page.getByRole('button', { name: "Let's predict" }).click();
  513 | };
  514 | 
  515 | const continueButton = (page: Page) =>
  516 |   page.getByRole('button', { exact: true, name: 'Continue' });
  517 | 
  518 | const chooseVisibleRadio = async (page: Page, name: string) => {
  519 |   const radio = page.getByRole('radio', { exact: true, name });
  520 | 
  521 |   await expect(radio).toBeVisible();
  522 |   await radio.check();
  523 | };
  524 | 
  525 | const teamNumberInput = (page: Page, teamName: string, fieldName: string) =>
  526 |   page.getByRole('spinbutton', { name: `${teamName} ${fieldName}` });
  527 | 
  528 | const reviewSection = (page: Page, label: string) =>
  529 |   page.getByRole('group', { name: `Review ${label}` });
  530 | 
  531 | const expectStep = async (page: Page, current: number, total = 9) => {
  532 |   await expect(page.getByText(`Step ${current} of ${total}`)).toBeVisible({
  533 |     timeout: NAVIGATION_ATTEMPT_TIMEOUT_MS,
  534 |   });
  535 | };
  536 | 
  537 | const saveRevisedPredictionButton = (page: Page) =>
  538 |   page.getByRole('button', { name: 'Save revised prediction' });
  539 | 
  540 | const animationsButton = (page: Page, name: 'Off' | 'On') =>
  541 |   page.getByRole('button', { exact: true, name });
  542 | 
  543 | const waitForKaplayReady = async (page: Page) => {
  544 |   markStage(page, 'kaplay-ready:wait-start');
  545 |   await expect(page.getByTestId('kaplay-match-result-stage')).toBeVisible({
  546 |     timeout: NAVIGATION_ATTEMPT_TIMEOUT_MS,
  547 |   });
  548 |   await expect(page.getByText('Loading animation preview.')).toHaveCount(0);
  549 |   await expect(page.getByTestId('kaplay-match-result-canvas')).toBeVisible();
  550 |   markStage(page, 'kaplay-ready:success');
  551 | };
  552 | 
  553 | const waitForKaplayDebugLayout = async (page: Page) => {
  554 |   await page.waitForFunction(
  555 |     () => {
  556 |       const layout = window.__RUGBY_ROOSTER_KAPLAY_LAST_LAYOUT__;
  557 | 
  558 |       return (
  559 |         Boolean(layout) &&
  560 |         Array.isArray(layout?.choices) &&
  561 |         layout.choices.length > 0 &&
  562 |         layout.synchronized === true &&
  563 |         layout.viewport.renderedContentBounds !== null &&
  564 |         layout.viewport.engine.width === layout.stage.width &&
  565 |         layout.viewport.engine.height === layout.stage.height
  566 |       );
  567 |     },
  568 |     undefined,
  569 |     { timeout: NAVIGATION_ATTEMPT_TIMEOUT_MS },
  570 |   );
  571 | };
  572 | 
  573 | const waitForHitTestableChoices = async (page: Page) => {
  574 |   await waitForKaplayDebugLayout(page);
  575 |   await page.waitForFunction(
  576 |     () => {
  577 |       const layout = window.__RUGBY_ROOSTER_KAPLAY_LAST_LAYOUT__;
  578 | 
  579 |       return (
  580 |         layout?.synchronized === true &&
  581 |         layout.selectedChoice === null &&
  582 |         layout.choices.length === 3 &&
  583 |         layout.choices.every((choice) => choice.hitTestable)
  584 |       );
  585 |     },
  586 |     undefined,
  587 |     { timeout: NAVIGATION_ATTEMPT_TIMEOUT_MS },
  588 |   );
  589 | };
  590 | 
  591 | const retryIfAnimationFailureIsVisible = async (page: Page) => {
  592 |   const retryButton = page.getByRole('button', { name: 'Retry animations' });
  593 | 
  594 |   if (
  595 |     await retryButton
  596 |       .isVisible({
  597 |         timeout: 1_000,
  598 |       })
  599 |       .catch(() => false)
  600 |   ) {
  601 |     await retryButton.click();
  602 |   }
  603 | };
  604 | 
  605 | const clickCanvasChoice = async (page: Page, choiceIndex: 0 | 1 | 2) => {
  606 |   const canvas = page.getByTestId('kaplay-match-result-canvas');
> 607 |   const box = await canvas.boundingBox();
      |                            ^ Error: locator.boundingBox: Target page, context or browser has been closed
  608 | 
  609 |   if (!box) {
  610 |     throw new Error('Kaplay canvas is not visible.');
  611 |   }
  612 | 
  613 |   await waitForKaplayDebugLayout(page);
  614 |   const choice = await page.evaluate((index) => {
  615 |     const layout = window.__RUGBY_ROOSTER_KAPLAY_LAST_LAYOUT__;
  616 |     const projectedChoice = layout?.choices[index];
  617 | 
  618 |     if (!layout || !projectedChoice) {
  619 |       throw new Error('Kaplay choice layout is not available.');
  620 |     }
  621 | 
  622 |     if (!projectedChoice.hitTestable) {
  623 |       throw new Error('Kaplay choice layout is not currently hit-testable.');
  624 |     }
  625 | 
  626 |     return {
  627 |       centerX: projectedChoice.rect.x + projectedChoice.rect.width / 2,
  628 |       centerY: projectedChoice.rect.y + projectedChoice.rect.height / 2,
  629 |       content: layout.viewport.renderedContentBounds,
  630 |       stageHeight: layout.stage.height,
  631 |       stageWidth: layout.stage.width,
  632 |     };
  633 |   }, choiceIndex);
  634 | 
  635 |   if (!choice.content) {
  636 |     throw new Error('Kaplay rendered content bounds are not available.');
  637 |   }
  638 | 
  639 |   await canvas.click({
  640 |     position: {
  641 |       x:
  642 |         choice.content.x +
  643 |         (choice.centerX / choice.stageWidth) * choice.content.width,
  644 |       y:
  645 |         choice.content.y +
  646 |         (choice.centerY / choice.stageHeight) * choice.content.height,
  647 |     },
  648 |   });
  649 | };
  650 | 
  651 | const collectKaplayLayoutEvidence = async (page: Page, label: string) => {
  652 |   await waitForKaplayDebugLayout(page);
  653 |   await page.waitForFunction(
  654 |     () => {
  655 |       const canvas = document.querySelector<HTMLCanvasElement>(
  656 |         '[data-testid="kaplay-match-result-canvas"]',
  657 |       );
  658 |       const layout = window.__RUGBY_ROOSTER_KAPLAY_LAST_LAYOUT__;
  659 | 
  660 |       if (!canvas || !layout) {
  661 |         return false;
  662 |       }
  663 | 
  664 |       return (
  665 |         layout.synchronized === true &&
  666 |         layout.viewport.renderedContentBounds !== null &&
  667 |         layout.viewport.engine.width === layout.stage.width &&
  668 |         layout.viewport.engine.height === layout.stage.height &&
  669 |         Math.abs(
  670 |           layout.displayScale -
  671 |             layout.viewport.renderedContentBounds.width / layout.stage.width,
  672 |         ) < 0.01
  673 |       );
  674 |     },
  675 |     undefined,
  676 |     { timeout: NAVIGATION_ATTEMPT_TIMEOUT_MS },
  677 |   );
  678 |   const canvas = page.getByTestId('kaplay-match-result-canvas');
  679 |   const box = await canvas.boundingBox();
  680 | 
  681 |   if (!box) {
  682 |     throw new Error('Kaplay canvas is not visible for layout evidence.');
  683 |   }
  684 | 
  685 |   const layout = await page.evaluate(() => {
  686 |     const currentLayout = window.__RUGBY_ROOSTER_KAPLAY_LAST_LAYOUT__;
  687 | 
  688 |     if (!currentLayout) {
  689 |       throw new Error('Kaplay layout evidence is not available.');
  690 |     }
  691 | 
  692 |     return currentLayout;
  693 |   });
  694 |   const selectedValue = await page
  695 |     .locator('[data-testid="kaplay-match-result-choice-bridge"] input:checked')
  696 |     .evaluate((input: HTMLInputElement) => input.value)
  697 |     .catch(() => null);
  698 | 
  699 |   return {
  700 |     canvasCss: {
  701 |       height: box.height,
  702 |       width: box.width,
  703 |     },
  704 |     label,
  705 |     layout,
  706 |     measuredAt: utcNow(),
  707 |     selectedValue,
```