# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: kaplay-prediction-preview.spec.ts >> Kaplay prediction preview >> uses Standard when reduced motion blocks automatic activation
- Location: tests/e2e/kaplay-prediction-preview.spec.ts:1422:7

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: expect(locator).toBeVisible() failed

Locator:  getByTestId('kaplay-match-result-canvas')
Expected: visible
Received: undefined

```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - banner [ref=f2e4]:
    - generic [ref=f2e5]:
      - link "Rugby Rooster" [ref=f2e6] [cursor=pointer]:
        - /url: /
        - generic [aria-hidden] [ref=f2e7]: RR
      - navigation "Primary navigation" [ref=f2e9]:
        - list [ref=f2e10]:
          - listitem [ref=f2e11]:
            - link "Rugby Rooster" [ref=f2e12] [cursor=pointer]:
              - /url: /
          - listitem [ref=f2e13]:
            - link "Games" [ref=f2e14] [cursor=pointer]:
              - /url: /games
          - listitem [ref=f2e15]:
            - link "Account" [ref=f2e16] [cursor=pointer]:
              - /url: /account
          - listitem [ref=f2e17]:
            - button "Sign out" [ref=f2e19] [cursor=pointer]
  - main [ref=f2e20]:
    - generic [ref=f2e21]:
      - link "Back to fixture" [ref=f2e22] [cursor=pointer]:
        - /url: /games/Q9cKBLKrfGJGrWEuL
      - generic [ref=f2e23]:
        - generic [ref=f2e24]: Published
        - generic [ref=f2e25]: Open before kickoff
        - generic [ref=f2e26]: kaplay-reduced-motion Cup
      - heading "Cape Town Very Long Club Name mu8kynq70abd XV vs Johannesburg Equally Long Club Name mu8kynq789c9 XV" [level=1] [ref=f2e27]
      - paragraph [ref=f2e28]: "Kickoff: 01 Jun 2098, 14:00 SAST"
    - generic [ref=f2e29]:
      - generic [ref=f2e31]:
        - generic [ref=f2e32]:
          - paragraph [ref=f2e33]: Animations
          - paragraph [ref=f2e34]: Animated Match Result is available. Other prediction steps currently use the standard experience.
        - group "Animations" [ref=f2e35]:
          - button "Off" [ref=f2e36] [cursor=pointer]
          - button "On" [pressed] [ref=f2e37] [cursor=pointer]
      - generic [ref=f2e38]:
        - group "Step 1 of 9" [ref=f2e39]
        - generic [ref=f2e50]:
          - paragraph [ref=f2e51]: Step 1 of 9
          - heading "TIME TO PICK A SIDE!" [level=2] [ref=f2e52]
          - paragraph [ref=f2e53]: Who gets the result?
          - paragraph [ref=f2e54]: Get the result wrong and lose 5,000 points—half your starting score. Pick carefully!
        - generic "TIME TO PICK A SIDE!" [ref=f2e56]
        - group "TIME TO PICK A SIDE!" [ref=f2e57]:
          - generic [ref=f2e58]: Match Result animation choices
          - generic [ref=f2e59]:
            - radio "Cape Town Very Long Club Name mu8kynq70abd XV" [ref=f2e60]
            - text: Cape Town Very Long Club Name mu8kynq70abd XV
          - generic [ref=f2e61]:
            - radio "Johannesburg Equally Long Club Name mu8kynq789c9 XV" [ref=f2e62]
            - text: Johannesburg Equally Long Club Name mu8kynq789c9 XV
          - generic [ref=f2e63]:
            - radio "Draw" [ref=f2e64]
            - text: Draw
        - generic [ref=f2e65]:
          - button "Back" [ref=f2e66] [cursor=pointer]
          - button "Continue" [ref=f2e68] [cursor=pointer]
  - contentinfo [ref=f2e69]:
    - generic [ref=f2e70]:
      - paragraph [ref=f2e71]: Rugby Rooster account access build.
      - link "Admin" [ref=f2e72] [cursor=pointer]:
        - /url: /admin
```

# Test source

```ts
  628 |       centerY: projectedChoice.rect.y + projectedChoice.rect.height / 2,
  629 |       content: layout.viewport.renderedContentBounds,
  630 |       stageHeight: layout.stage.height,
  631 |       stageWidth: layout.stage.width,
  632 |     };
  633 |   }, choiceIndex);
  634 | 
  635 |   if (!choice.content) {
  636 |     throw new Error('Kaplay rendered content bounds are not available.');
  637 |   }
  638 | 
  639 |   await canvas.click({
  640 |     position: {
  641 |       x:
  642 |         choice.content.x +
  643 |         (choice.centerX / choice.stageWidth) * choice.content.width,
  644 |       y:
  645 |         choice.content.y +
  646 |         (choice.centerY / choice.stageHeight) * choice.content.height,
  647 |     },
  648 |   });
  649 | };
  650 | 
  651 | const collectKaplayLayoutEvidence = async (page: Page, label: string) => {
  652 |   await waitForKaplayDebugLayout(page);
  653 |   await page.waitForFunction(
  654 |     () => {
  655 |       const canvas = document.querySelector<HTMLCanvasElement>(
  656 |         '[data-testid="kaplay-match-result-canvas"]',
  657 |       );
  658 |       const layout = window.__RUGBY_ROOSTER_KAPLAY_LAST_LAYOUT__;
  659 | 
  660 |       if (!canvas || !layout) {
  661 |         return false;
  662 |       }
  663 | 
  664 |       return (
  665 |         layout.synchronized === true &&
  666 |         layout.viewport.renderedContentBounds !== null &&
  667 |         layout.viewport.engine.width === layout.stage.width &&
  668 |         layout.viewport.engine.height === layout.stage.height &&
  669 |         Math.abs(
  670 |           layout.displayScale -
  671 |             layout.viewport.renderedContentBounds.width / layout.stage.width,
  672 |         ) < 0.01
  673 |       );
  674 |     },
  675 |     undefined,
  676 |     { timeout: NAVIGATION_ATTEMPT_TIMEOUT_MS },
  677 |   );
  678 |   const canvas = page.getByTestId('kaplay-match-result-canvas');
  679 |   const box = await canvas.boundingBox();
  680 | 
  681 |   if (!box) {
  682 |     throw new Error('Kaplay canvas is not visible for layout evidence.');
  683 |   }
  684 | 
  685 |   const layout = await page.evaluate(() => {
  686 |     const currentLayout = window.__RUGBY_ROOSTER_KAPLAY_LAST_LAYOUT__;
  687 | 
  688 |     if (!currentLayout) {
  689 |       throw new Error('Kaplay layout evidence is not available.');
  690 |     }
  691 | 
  692 |     return currentLayout;
  693 |   });
  694 |   const selectedValue = await page
  695 |     .locator('[data-testid="kaplay-match-result-choice-bridge"] input:checked')
  696 |     .evaluate((input: HTMLInputElement) => input.value)
  697 |     .catch(() => null);
  698 | 
  699 |   return {
  700 |     canvasCss: {
  701 |       height: box.height,
  702 |       width: box.width,
  703 |     },
  704 |     label,
  705 |     layout,
  706 |     measuredAt: utcNow(),
  707 |     selectedValue,
  708 |     viewport: page.viewportSize(),
  709 |   };
  710 | };
  711 | 
  712 | const writeEvidenceJson = (name: string, value: unknown) => {
  713 |   writeFileSync(
  714 |     evidenceArtifactPath(name),
  715 |     `${JSON.stringify(value, null, 2)}\n`,
  716 |   );
  717 | };
  718 | 
  719 | const writePngDataUrl = (name: string, dataUrl: string) => {
  720 |   const encoded = dataUrl.replace(/^data:image\/png;base64,/, '');
  721 | 
  722 |   writeFileSync(evidenceScreenshotPath(name), Buffer.from(encoded, 'base64'));
  723 | };
  724 | 
  725 | const captureCanvasBitmap = async (page: Page, name: string) => {
  726 |   const canvas = page.getByTestId('kaplay-match-result-canvas');
  727 | 
> 728 |   await expect(canvas).toBeVisible({ timeout: SCREENSHOT_CAPTURE_TIMEOUT_MS });
      |                        ^ Error: expect(locator).toBeVisible() failed
  729 | 
  730 |   const dataUrl = await canvas.evaluate(
  731 |     (node: HTMLCanvasElement) => node.toDataURL('image/png'),
  732 |     undefined,
  733 |     {
  734 |       timeout: SCREENSHOT_CAPTURE_TIMEOUT_MS,
  735 |     },
  736 |   );
  737 | 
  738 |   writePngDataUrl(name, dataUrl);
  739 | };
  740 | 
  741 | const startCanvasRecording = async (page: Page) => {
  742 |   await page.evaluate(() => {
  743 |     const canvas = document.querySelector<HTMLCanvasElement>(
  744 |       '[data-testid="kaplay-match-result-canvas"]',
  745 |     );
  746 | 
  747 |     if (!canvas) {
  748 |       throw new Error('Kaplay canvas is not available for recording.');
  749 |     }
  750 | 
  751 |     const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp8')
  752 |       ? 'video/webm;codecs=vp8'
  753 |       : 'video/webm';
  754 |     const stream = canvas.captureStream(60);
  755 |     const chunks: Blob[] = [];
  756 |     const recorder = new MediaRecorder(stream, { mimeType });
  757 |     const started = new Promise<void>((resolve, reject) => {
  758 |       recorder.addEventListener(
  759 |         'error',
  760 |         () => {
  761 |           reject(new Error('Kaplay canvas recording failed to start.'));
  762 |         },
  763 |         { once: true },
  764 |       );
  765 |       recorder.addEventListener('start', () => resolve(), { once: true });
  766 |     });
  767 |     const finished = new Promise<{
  768 |       readonly base64: string;
  769 |       readonly mimeType: string;
  770 |     }>((resolve, reject) => {
  771 |       recorder.ondataavailable = (event) => {
  772 |         if (event.data.size > 0) {
  773 |           chunks.push(event.data);
  774 |         }
  775 |       };
  776 |       recorder.onerror = () => {
  777 |         reject(new Error('Kaplay canvas recording failed.'));
  778 |       };
  779 |       recorder.onstop = () => {
  780 |         const blob = new Blob(chunks, { type: mimeType });
  781 |         const reader = new FileReader();
  782 | 
  783 |         reader.onerror = () => reject(new Error('Recording read failed.'));
  784 |         reader.onloadend = () => {
  785 |           const result = String(reader.result ?? '');
  786 |           const base64 = result.includes(',') ? result.split(',')[1] : '';
  787 | 
  788 |           resolve({ base64, mimeType });
  789 |         };
  790 |         reader.readAsDataURL(blob);
  791 |       };
  792 |     });
  793 | 
  794 |     (
  795 |       window as unknown as {
  796 |         __RUGBY_ROOSTER_CANVAS_RECORDING__?: {
  797 |           readonly finished: Promise<{
  798 |             readonly base64: string;
  799 |             readonly mimeType: string;
  800 |           }>;
  801 |           readonly recorder: MediaRecorder;
  802 |           readonly started: Promise<void>;
  803 |           readonly stream: MediaStream;
  804 |         };
  805 |       }
  806 |     ).__RUGBY_ROOSTER_CANVAS_RECORDING__ = {
  807 |       finished,
  808 |       recorder,
  809 |       started,
  810 |       stream,
  811 |     };
  812 | 
  813 |     recorder.start(100);
  814 |   });
  815 | 
  816 |   await page.evaluate(() => {
  817 |     const holder = (
  818 |       window as unknown as {
  819 |         __RUGBY_ROOSTER_CANVAS_RECORDING__?: {
  820 |           readonly recorder: MediaRecorder;
  821 |           readonly started: Promise<void>;
  822 |         };
  823 |       }
  824 |     ).__RUGBY_ROOSTER_CANVAS_RECORDING__;
  825 | 
  826 |     if (!holder) {
  827 |       throw new Error('No Kaplay canvas recording was created.');
  828 |     }
```