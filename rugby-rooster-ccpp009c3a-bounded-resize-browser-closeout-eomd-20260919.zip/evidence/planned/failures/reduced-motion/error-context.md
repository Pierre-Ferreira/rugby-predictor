# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: kaplay-prediction-preview.spec.ts >> Kaplay prediction preview >> uses Standard when reduced motion blocks automatic activation
- Location: tests/e2e/kaplay-prediction-preview.spec.ts:1423:7

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: page.screenshot: Target page, context or browser has been closed
```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - banner [ref=f2e4]:
    - generic [ref=f2e5]:
      - link "Rugby Rooster" [ref=f2e6] [cursor=pointer]:
        - /url: /
        - generic [aria-hidden] [ref=f2e7]: RR
      - navigation "Primary navigation" [ref=f2e9]:
        - list [ref=f2e10]:
          - listitem [ref=f2e11]:
            - link "Rugby Rooster" [ref=f2e12] [cursor=pointer]:
              - /url: /
          - listitem [ref=f2e13]:
            - link "Games" [ref=f2e14] [cursor=pointer]:
              - /url: /games
          - listitem [ref=f2e15]:
            - link "Account" [ref=f2e16] [cursor=pointer]:
              - /url: /account
          - listitem [ref=f2e17]:
            - button "Sign out" [ref=f2e19] [cursor=pointer]
  - main [ref=f2e20]:
    - generic [ref=f2e21]:
      - link "Back to fixture" [ref=f2e22] [cursor=pointer]:
        - /url: /games/ydDmnvANRsZwo4f7G
      - generic [ref=f2e23]:
        - generic [ref=f2e24]: Published
        - generic [ref=f2e25]: Open before kickoff
        - generic [ref=f2e26]: kaplay-reduced-motion Cup
      - heading "Cape Town Very Long Club Name mu8kq57y15bb XV vs Johannesburg Equally Long Club Name mu8kq57y37e2 XV" [level=1] [ref=f2e27]
      - paragraph [ref=f2e28]: "Kickoff: 01 Jun 2098, 14:00 SAST"
    - generic [ref=f2e29]:
      - generic [ref=f2e31]:
        - generic [ref=f2e32]:
          - paragraph [ref=f2e33]: Animations
          - paragraph [ref=f2e34]: Animated Match Result is available. Other prediction steps currently use the standard experience.
        - group "Animations" [ref=f2e35]:
          - button "Off" [ref=f2e36] [cursor=pointer]
          - button "On" [pressed] [ref=f2e37] [cursor=pointer]
      - generic [ref=f2e38]:
        - group "Step 1 of 9" [ref=f2e39]
        - generic [ref=f2e50]:
          - paragraph [ref=f2e51]: Step 1 of 9
          - heading "CALL IT!" [level=2] [ref=f2e52]
          - paragraph [ref=f2e53]: Who's taking this one?
          - paragraph [ref=f2e54]: Get the result wrong and lose 5,000 points—half your starting score. Pick carefully!
        - generic "CALL IT!" [ref=f2e56]
        - group "CALL IT!" [ref=f2e57]:
          - generic [ref=f2e58]: Match Result animation choices
          - generic [ref=f2e59]:
            - radio "Cape Town Very Long Club Name mu8kq57y15bb XV" [ref=f2e60]
            - text: Cape Town Very Long Club Name mu8kq57y15bb XV
          - generic [ref=f2e61]:
            - radio "Johannesburg Equally Long Club Name mu8kq57y37e2 XV" [ref=f2e62]
            - text: Johannesburg Equally Long Club Name mu8kq57y37e2 XV
          - generic [ref=f2e63]:
            - radio "Draw" [ref=f2e64]
            - text: Draw
        - generic [ref=f2e65]:
          - button "Back" [ref=f2e66] [cursor=pointer]
          - button "Continue" [ref=f2e68] [cursor=pointer]
  - contentinfo [ref=f2e69]:
    - generic [ref=f2e70]:
      - paragraph [ref=f2e71]: Rugby Rooster account access build.
      - link "Admin" [ref=f2e72] [cursor=pointer]:
        - /url: /admin
```

# Test source

```ts
  1367 |   test('preserves the selected answer when switched Off during an active shove', async ({
  1368 |     page,
  1369 |   }) => {
  1370 |     const { team2 } = await createPredictionAtMatchResult(
  1371 |       page,
  1372 |       'kaplay-off-during-shove',
  1373 |     );
  1374 | 
  1375 |     await waitForKaplayReady(page);
  1376 |     markStage(page, 'off-during-shove:canvas-choice-click');
  1377 |     await clickCanvasChoice(page, 1);
  1378 |     await expect(page.getByTestId('kaplay-match-result-picked')).toContainText(
  1379 |       `You picked ${team2}`,
  1380 |     );
  1381 | 
  1382 |     markStage(page, 'off-during-shove:animations-off');
  1383 |     await animationsButton(page, 'Off').click();
  1384 |     await expect(page.getByTestId('kaplay-match-result-stage')).toHaveCount(0);
  1385 |     await expect(
  1386 |       page.getByRole('radio', { exact: true, name: team2 }),
  1387 |     ).toBeChecked();
  1388 |     await page.screenshot({
  1389 |       fullPage: true,
  1390 |       path: evidenceScreenshotPath('standard-after-interruption.png'),
  1391 |       timeout: SCREENSHOT_CAPTURE_TIMEOUT_MS,
  1392 |     });
  1393 |   });
  1394 | 
  1395 |   test('captures a slowed browser review of the same shove motion', async ({
  1396 |     page,
  1397 |   }) => {
  1398 |     await createPredictionAtMatchResult(page, 'kaplay-slow-review');
  1399 |     await page.evaluate(() => {
  1400 |       window.__RUGBY_ROOSTER_KAPLAY_PREVIEW_TEST__ = {
  1401 |         motionTimeScale: 0.25,
  1402 |       };
  1403 |     });
  1404 |     await animationsButton(page, 'Off').click();
  1405 |     await animationsButton(page, 'On').click();
  1406 |     await waitForKaplayReady(page);
  1407 | 
  1408 |     markStage(page, 'slow-review:recording-start');
  1409 |     await startCanvasRecording(page);
  1410 |     await page.waitForTimeout(300);
  1411 |     await clickCanvasChoice(page, 0);
  1412 |     await expect(page.getByTestId('kaplay-match-result-picked')).toContainText(
  1413 |       'You picked',
  1414 |     );
  1415 |     await page.waitForTimeout(4_200);
  1416 |     await stopCanvasRecording(page, 'match-result-shove-slow-review.webm');
  1417 | 
  1418 |     await page.evaluate(() => {
  1419 |       window.__RUGBY_ROOSTER_KAPLAY_PREVIEW_TEST__ = {};
  1420 |     });
  1421 |   });
  1422 | 
  1423 |   test('uses Standard when reduced motion blocks automatic activation', async ({
  1424 |     page,
  1425 |   }) => {
  1426 |     const longTeam1 = `${uniqueLabel('Cape Town Very Long Club Name')} XV`;
  1427 |     const longTeam2 = `${uniqueLabel('Johannesburg Equally Long Club Name')} XV`;
  1428 |     const measurements: BrowserEvidenceEntry[] = [];
  1429 | 
  1430 |     await page.setViewportSize({ height: 760, width: 390 });
  1431 |     await page.emulateMedia({ reducedMotion: 'reduce' });
  1432 |     await createPredictionAtMatchResult(
  1433 |       page,
  1434 |       'kaplay-reduced-motion',
  1435 |       {
  1436 |         team1: longTeam1,
  1437 |         team2: longTeam2,
  1438 |       },
  1439 |       {
  1440 |         beforeStart: async () => {
  1441 |           await page.evaluate(() => {
  1442 |             window.__RUGBY_ROOSTER_KAPLAY_PREVIEW_TEST__ = {
  1443 |               motionTimeScale: 0.25,
  1444 |             };
  1445 |           });
  1446 |         },
  1447 |       },
  1448 |     );
  1449 | 
  1450 |     await expect(
  1451 |       page.getByText('Your device/browser preference keeps animations off.'),
  1452 |     ).toBeVisible();
  1453 |     await expect(page.getByTestId('kaplay-match-result-stage')).toHaveCount(0);
  1454 |     await expect
  1455 |       .poll(() =>
  1456 |         page.evaluate(() => window.__RUGBY_ROOSTER_KAPLAY_IMPORT_COUNT__ ?? 0),
  1457 |       )
  1458 |       .toBe(0);
  1459 | 
  1460 |     markStage(page, 'reduced-motion:emulate-no-preference');
  1461 |     await page.emulateMedia({ reducedMotion: 'no-preference' });
  1462 |     await waitForKaplayReady(page);
  1463 |     const mobile390Initial = await collectKaplayLayoutEvidence(
  1464 |       page,
  1465 |       '390px viewport initial choices',
  1466 |     );
> 1467 |     await page.screenshot({
       |                ^ Error: page.screenshot: Target page, context or browser has been closed
  1468 |       fullPage: true,
  1469 |       path: evidenceScreenshotPath('mobile-390-match-result-preview.png'),
  1470 |       timeout: SCREENSHOT_CAPTURE_TIMEOUT_MS,
  1471 |     });
  1472 |     await screenshotCanvasCrop(page, 'mobile-390-choice-area-crop.png');
  1473 |     markStage(page, 'reduced-motion:mobile-390-measured', {
  1474 |       canvasCss: mobile390Initial.canvasCss,
  1475 |       choices: mobile390Initial.layout.choices.map((choice) => ({
  1476 |         label: choice.label,
  1477 |         labelCssFontSize: choice.labelCssFontSize,
  1478 |         targetCssHeight: choice.targetCssHeight,
  1479 |       })),
  1480 |     });
  1481 | 
  1482 |     markStage(page, 'reduced-motion:mobile-390-draw-click');
  1483 |     await clickCanvasChoice(page, 2);
  1484 |     await expect(page.getByTestId('kaplay-match-result-picked')).toContainText(
  1485 |       'You picked Draw',
  1486 |     );
  1487 |     const mobile390DrawRejected = await collectKaplayLayoutEvidence(
  1488 |       page,
  1489 |       '390px viewport Draw rejected arrangement',
  1490 |     );
  1491 |     await page.screenshot({
  1492 |       fullPage: true,
  1493 |       path: evidenceScreenshotPath('mobile-390-draw-rejected.png'),
  1494 |       timeout: SCREENSHOT_CAPTURE_TIMEOUT_MS,
  1495 |     });
  1496 |     await screenshotCanvasCrop(page, 'mobile-390-draw-rejected-crop.png');
  1497 |     await page.waitForTimeout(3_400);
  1498 |     const mobile390Settled = await collectKaplayLayoutEvidence(
  1499 |       page,
  1500 |       '390px viewport settled Draw',
  1501 |     );
  1502 |     await page.screenshot({
  1503 |       fullPage: true,
  1504 |       path: evidenceScreenshotPath('mobile-390-draw-settled.png'),
  1505 |       timeout: SCREENSHOT_CAPTURE_TIMEOUT_MS,
  1506 |     });
  1507 |     measurements.push({
  1508 |       initial: mobile390Initial,
  1509 |       rejected: mobile390DrawRejected,
  1510 |       settled: mobile390Settled,
  1511 |       viewportWidth: 390,
  1512 |     });
  1513 | 
  1514 |     await page.getByRole('button', { name: 'Change my selection' }).click();
  1515 |     await page.setViewportSize({ height: 760, width: 360 });
  1516 |     const mobile360Initial = await collectKaplayLayoutEvidence(
  1517 |       page,
  1518 |       '360px viewport initial choices',
  1519 |     );
  1520 |     await page.screenshot({
  1521 |       fullPage: true,
  1522 |       path: evidenceScreenshotPath('mobile-360-match-result-preview.png'),
  1523 |       timeout: SCREENSHOT_CAPTURE_TIMEOUT_MS,
  1524 |     });
  1525 |     await screenshotCanvasCrop(page, 'mobile-360-choice-area-crop.png');
  1526 |     markStage(page, 'reduced-motion:mobile-360-measured', {
  1527 |       canvasCss: mobile360Initial.canvasCss,
  1528 |       choices: mobile360Initial.layout.choices.map((choice) => ({
  1529 |         label: choice.label,
  1530 |         labelCssFontSize: choice.labelCssFontSize,
  1531 |         targetCssHeight: choice.targetCssHeight,
  1532 |       })),
  1533 |     });
  1534 | 
  1535 |     markStage(page, 'reduced-motion:mobile-360-team1-click');
  1536 |     await clickCanvasChoice(page, 0);
  1537 |     await expect(page.getByTestId('kaplay-match-result-picked')).toContainText(
  1538 |       `You picked ${longTeam1}`,
  1539 |     );
  1540 |     await page.getByRole('button', { name: 'Change my selection' }).click();
  1541 |     markStage(page, 'reduced-motion:mobile-360-draw-click');
  1542 |     await clickCanvasChoice(page, 2);
  1543 |     await expect(page.getByTestId('kaplay-match-result-picked')).toContainText(
  1544 |       'You picked Draw',
  1545 |     );
  1546 |     const mobile360DrawRejected = await collectKaplayLayoutEvidence(
  1547 |       page,
  1548 |       '360px viewport Draw rejected arrangement',
  1549 |     );
  1550 |     await page.screenshot({
  1551 |       fullPage: true,
  1552 |       path: evidenceScreenshotPath('mobile-360-draw-rejected.png'),
  1553 |       timeout: SCREENSHOT_CAPTURE_TIMEOUT_MS,
  1554 |     });
  1555 |     await screenshotCanvasCrop(page, 'mobile-360-draw-rejected-crop.png');
  1556 |     await page.waitForTimeout(3_400);
  1557 |     const mobile360Settled = await collectKaplayLayoutEvidence(
  1558 |       page,
  1559 |       '360px viewport settled Draw',
  1560 |     );
  1561 |     await page.screenshot({
  1562 |       fullPage: true,
  1563 |       path: evidenceScreenshotPath('mobile-360-draw-settled.png'),
  1564 |       timeout: SCREENSHOT_CAPTURE_TIMEOUT_MS,
  1565 |     });
  1566 |     measurements.push({
  1567 |       initial: mobile360Initial,
```